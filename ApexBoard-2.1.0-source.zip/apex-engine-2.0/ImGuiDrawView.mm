// ============================================================================
//  ImGuiDrawView.mm  —  APEX ENGINE 2.1.0  (iOS / 8 Ball Pool)
//
//  Render host only:
//    Metal device → ImGui context → per-frame engine tick → interface frame.
//  The interface lives in Apex/ (pure ImGui, no UIKit), the game logic lives in
//  Core/Engine.h, and Bridge/EngineBridge.h is the single seam between them.
//
//  Surfaces:
//    · floating orb   — tap to summon/dismiss, drag to dock, hold to ghost
//    · apex board     — 4 pages, opens with a bloom from the orb
//    · fallback       — 3-finger triple tap (works even when the orb is hidden)
// ============================================================================

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <dlfcn.h>

#import "LoadView/ImGuiDrawView.h"
#import "LoadView/ImGuiLoad.h"
#import "LoadView/HeeeNoScreenShotView.h"

#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_metal.h"
#include "ImGui/zzz.h"

#include "Apex/ApexStyle.h"
#include "Apex/ApexPrimitives.h"
#include "Apex/ApexWidgets.h"
#include "Apex/ApexModel.h"
#include "Apex/ApexOrb.h"
#include "Apex/ApexShell.h"
#include "Apex/ApexLogo.h"
#include "Bridge/EngineBridge.h"

// ============================================================================
//  Globals
// ============================================================================
id<MTLDevice>  g_espMetalDevice = nil;
HeeeNoScreenShotView *hideViewSylphin3107 = nil;

static id<MTLTexture>  g_apexMarkTexture = nil;
static bool            g_menuVisible     = false;
static ax::ShellState  g_shell;
static ax::OrbState    g_orb;
static float           g_clock           = 0.0f;
static bool            g_booted          = false;

// gesture plumbing
static id              g_gestureTarget = nil;
static __weak UIWindow *g_gestureWindow = nil;
static UITapGestureRecognizer *g_gesture = nil;

// ============================================================================
//  Base64 → Metal texture
//  The mark ships inside the binary (Apex/ApexLogo.h); decode once at boot.
// ============================================================================
static id<MTLTexture> ApexTextureFromBase64(const char *b64, id<MTLDevice> device) {
    if (!b64 || !device) return nil;
    @autoreleasepool {
        NSString *encoded = [NSString stringWithUTF8String:b64];
        NSData *data = [[NSData alloc] initWithBase64EncodedString:encoded
                                                           options:NSDataBase64DecodingIgnoreUnknownCharacters];
        if (!data) return nil;
        UIImage *image = [UIImage imageWithData:data];
        if (!image) return nil;

        CGImageRef cg = image.CGImage;
        const size_t w = CGImageGetWidth(cg);
        const size_t h = CGImageGetHeight(cg);
        if (w == 0 || h == 0) return nil;

        void *buffer = calloc(w * h * 4, 1);
        if (!buffer) return nil;

        CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
        CGContextRef ctx = CGBitmapContextCreate(buffer, w, h, 8, w * 4, space,
                                                 kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
        CGContextSetBlendMode(ctx, kCGBlendModeCopy);
        CGContextDrawImage(ctx, CGRectMake(0, 0, (CGFloat)w, (CGFloat)h), cg);
        CGContextRelease(ctx);
        CGColorSpaceRelease(space);

        MTLTextureDescriptor *desc =
            [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm
                                                               width:w height:h mipmapped:NO];
        desc.usage = MTLTextureUsageShaderRead;
        id<MTLTexture> tex = [device newTextureWithDescriptor:desc];
        if (tex) {
            [tex replaceRegion:MTLRegionMake2D(0, 0, w, h)
                   mipmapLevel:0
                     withBytes:buffer
                   bytesPerRow:w * 4];
        }
        free(buffer);
        return tex;
    }
}

// ============================================================================
//  Render view discovery (unchanged contract: find the game's drawable surface)
// ============================================================================
static UIView *GetGameRenderView(UIView *root) {
    if (!root) return nil;
    static NSArray<NSString *> *names;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        names = @[@"MTKView", @"EAGLView", @"GLKView", @"UnityView", @"SCNView"];
    });
    for (NSString *name in names) {
        Class c = NSClassFromString(name);
        if (c && [root isKindOfClass:c]) return root;
    }
    for (UIView *sub in root.subviews) {
        UIView *v = GetGameRenderView(sub);
        if (v) return v;
    }
    return nil;
}

static void EnableMultiTouch(UIView *imguiView) {
    UIWindow *window = [UIApplication sharedApplication].keyWindow
                       ?: [UIApplication sharedApplication].windows.firstObject;
    if (window) window.multipleTouchEnabled = YES;
    UIView *root = window.rootViewController.view;
    if (root) {
        root.multipleTouchEnabled = YES;
        UIView *game = GetGameRenderView(root);
        if (game) {
            game.multipleTouchEnabled = YES;
            game.exclusiveTouch = NO;
        }
    }
    if (imguiView) {
        imguiView.multipleTouchEnabled = YES;
        imguiView.exclusiveTouch = NO;
    }
}

// ============================================================================
//  Fallback gesture: 3 fingers, 3 taps. The orb is the primary entry point;
//  this exists for the ghosted state and for hardware that eats the overlay.
// ============================================================================
static void ApexGestureFired(id self, SEL _cmd, id sender) {
    dispatch_async(dispatch_get_main_queue(), ^{
        g_menuVisible = !g_menuVisible;
        if (g_menuVisible) g_shell.pageT = 0.0f;
        NSLog(@"[APEX] fallback gesture -> %s", g_menuVisible ? "OPEN" : "CLOSED");
    });
}

static void ApexAttachGesture(UIWindow *window) {
    if (!window) return;
    if (!g_gestureTarget) {
        g_gestureTarget = [[NSObject alloc] init];
        SEL sel = sel_registerName("apexFired:");
        if (!class_getInstanceMethod([NSObject class], sel))
            class_addMethod([NSObject class], sel, (IMP)ApexGestureFired, "v@:@");
    }
    if (g_gesture) {
        UIWindow *old = g_gestureWindow;
        if (old) [old removeGestureRecognizer:g_gesture];
        g_gesture = nil;
        g_gestureWindow = nil;
    }
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired    = 3;
    tap.numberOfTouchesRequired = 3;
    tap.cancelsTouchesInView    = NO;
    tap.delaysTouchesBegan      = NO;
    tap.delaysTouchesEnded      = NO;
    [tap addTarget:g_gestureTarget action:sel_registerName("apexFired:")];
    [window addGestureRecognizer:tap];
    g_gesture = tap;
    g_gestureWindow = window;
}

// ============================================================================
//  Boot
// ============================================================================
static ImGuiDrawView *g_hostView = nil;

static void ApexBootUI(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (g_booted) return;

        UIWindow *window = [UIApplication sharedApplication].keyWindow
                           ?: [UIApplication sharedApplication].windows.firstObject;
        UIView *root = window.rootViewController.view;
        if (!root) {
            // the game is still laying out — come back in a moment
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{ ApexBootUI(); });
            return;
        }

        Engine_Boot();
        Engine_Restore();

        if (!g_hostView) g_hostView = [[ImGuiDrawView alloc] init];

        if (!hideViewSylphin3107) {
            hideViewSylphin3107 =
                [[HeeeNoScreenShotView alloc] initWithFrame:[UIScreen mainScreen].bounds];
            hideViewSylphin3107.autoresizingMask =
                UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            hideViewSylphin3107.maskContent = NO;
            hideViewSylphin3107.passTouchToContent = NO;
            hideViewSylphin3107.orbTouchRect = CGRectNull;
            [root addSubview:hideViewSylphin3107];
        }
        if (g_hostView.view.superview == nil) {
            [hideViewSylphin3107 addSubview:g_hostView.view];
            g_hostView.view.userInteractionEnabled = YES;
            g_hostView.view.multipleTouchEnabled = YES;
        }

        EnableMultiTouch(g_hostView.view);
        ApexAttachGesture(window);

        // restore the surfaces where the operator left them
        g_orb.pos        = ImVec2(g_uiOrbX, g_uiOrbY);
        g_shell.offset   = ImVec2(g_uiPanelX, g_uiPanelY);
        g_shell.tab      = g_uiTab;
        g_shell.shownTab = g_uiTab;
        g_shell.visible  = true;
        g_shell.open     = 0.0f;
        g_shell.pageT    = 0.0f;
        g_menuVisible    = false;   // the orb is the front door now

        g_booted = true;
        NSLog(@"[APEX] UI online (orb anchored at %.2f/%.2f)", g_uiOrbX, g_uiOrbY);

        [[NSNotificationCenter defaultCenter]
            addObserverForName:UIApplicationDidBecomeActiveNotification
                        object:nil
                         queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification *note) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                UIWindow *w = [UIApplication sharedApplication].keyWindow;
                if (!w) return;
                if (![w.gestureRecognizers containsObject:g_gesture] || g_gestureWindow != w)
                    ApexAttachGesture(w);
                EnableMultiTouch(g_hostView.view);
            });
        }];
    });
}

// ============================================================================
//  View controller
// ============================================================================
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id<MTLDevice>      device;
@property (nonatomic, strong) id<MTLCommandQueue> queue;
@property (nonatomic, assign) CFTimeInterval      lastFrame;
@end

@implementation ImGuiDrawView

+ (void)load {
    [super load];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ ApexBootUI(); });
}

+ (void)showChange:(BOOL)open {
    g_menuVisible = open;
    if (open) g_shell.pageT = 0.0f;
}

- (MTKView *)mtkView { return (MTKView *)self.view; }

- (void)loadView {
    UIWindow *w = [UIApplication sharedApplication].windows.firstObject;
    CGSize s = w ? w.rootViewController.view.frame.size : [UIScreen mainScreen].bounds.size;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, s.width, s.height)];
}

- (instancetype)init {
    self = [super init];
    if (!self) return nil;

    _device = MTLCreateSystemDefaultDevice();
    _queue  = [_device newCommandQueue];
    if (!_device) {
        NSLog(@"[APEX] Metal unavailable");
        return self;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = NULL;
    io.LogFilename = NULL;

    ImGui::StyleColorsDark();
    ImGuiStyle &st = ImGui::GetStyle();
    st.WindowPadding    = ImVec2(0, 0);
    st.WindowBorderSize = 0.0f;
    st.WindowRounding   = 0.0f;
    st.AntiAliasedLines = true;
    st.AntiAliasedFill  = true;

    // One font for the whole board; every label is drawn with an explicit size
    // so the zoom animation scales type and geometry together.
    io.Fonts->AddFontFromMemoryCompressedTTF((void *)zzz_compressed_data, zzz_compressed_size,
                                             40.0f, NULL, io.Fonts->GetGlyphRangesVietnamese());

    ImGui_ImplMetal_Init(_device);
    g_espMetalDevice = _device;

    // Apex mark → GPU texture, exposed to the interface as an ImTextureID
    g_apexMarkTexture = ApexTextureFromBase64(kApexMarkBase64, _device);
    apex::Bind();
    if (g_apexMarkTexture)
        apex::g_model.logoTexture = (ImTextureID)(intptr_t)(__bridge void *)g_apexMarkTexture;

    g_shell.visible = true;
    g_shell.tab     = g_uiTab;
    g_shell.open    = 0.0f;
    g_shell.pageT   = 0.0f;
    g_orb.pos       = ImVec2(g_uiOrbX, g_uiOrbY);

    _lastFrame = CACurrentMediaTime();
    NSLog(@"[APEX] render host ready (mark tex: %@)", g_apexMarkTexture ? @"ok" : @"missing");
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mtkView.device            = self.device;
    self.mtkView.delegate          = self;
    self.mtkView.clearColor        = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor   = [UIColor clearColor];
    self.mtkView.clipsToBounds     = YES;
    self.mtkView.preferredFramesPerSecond = 60;
    self.mtkView.enableSetNeedsDisplay    = NO;
    self.mtkView.paused                   = NO;
}

- (void)Guest2 {}

- (void)updateIO:(UIEvent *)event {
    UITouch *any = event.allTouches.anyObject;
    if (!any) return;
    CGPoint p = [any locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(p.x, p.y);

    BOOL down = NO;
    for (UITouch *t in event.allTouches) {
        if (t.phase != UITouchPhaseEnded && t.phase != UITouchPhaseCancelled) { down = YES; break; }
    }
    io.MouseDown[0] = down;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIO:event]; }
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIO:event]; }
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIO:event]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIO:event]; }

- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size {}

- (void)drawInMTKView:(MTKView *)view {
    @autoreleasepool {
        ImGuiIO &io = ImGui::GetIO();
        io.DisplaySize.x = view.bounds.size.width;
        io.DisplaySize.y = view.bounds.size.height;

        CFTimeInterval now = CACurrentMediaTime();
        float dt = (float)(now - self.lastFrame);
        if (dt <= 0.0f || dt > 0.1f) dt = 1.0f / 60.0f;
        io.DeltaTime = dt;
        self.lastFrame = now;
        g_clock += dt;

        static CGFloat scale = 0;
        if (scale == 0) scale = view.window.screen.nativeScale ?: [UIScreen mainScreen].nativeScale;
        io.DisplayFramebufferScale = ImVec2(scale, scale);

        // ── capture guard sync ─────────────────────────────────────────────
        static bool lastGuard = false;
        if (g_noScreenShot != lastGuard) {
            lastGuard = g_noScreenShot;
            BOOL on = (BOOL)g_noScreenShot;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (hideViewSylphin3107) hideViewSylphin3107.maskContent = on;
            });
        }

        [self.view setUserInteractionEnabled:YES];

        MTLRenderPassDescriptor *rpd = view.currentRenderPassDescriptor;
        if (!rpd) return;
        id<MTLCommandBuffer> cb = [self.queue commandBuffer];
        if (!cb) return;
        id<MTLRenderCommandEncoder> enc = [cb renderCommandEncoderWithDescriptor:rpd];
        [enc pushDebugGroup:@"APEX board"];

        ImGui_ImplMetal_NewFrame(rpd);
        ImGui::NewFrame();

        // ── engine tick (automation runs even with the board closed) ───────
        @try { AutoPlay::Update(); }   @catch (NSException *e) { NSLog(@"[APEX] autoplay: %@", e); }
        @try { AutoQueue::Update(); }  @catch (NSException *e) { NSLog(@"[APEX] autoqueue: %@", e); }
        @try { Engine_DrawOverlay(ImGui::GetBackgroundDrawList()); }
        @catch (NSException *e) { NSLog(@"[APEX] overlay: %@", e); }

        apex::Refresh();
        const ImVec2 disp = io.DisplaySize;

        // ── open/close choreography ────────────────────────────────────────
        const float target = g_menuVisible ? 1.0f : 0.0f;
        const float speed  = g_menuVisible ? 3.6f : 7.5f;
        g_shell.open += (target - g_shell.open) * (1.0f - expf(-speed * dt));
        if (!g_menuVisible && g_shell.open < 0.015f) g_shell.open = 0.0f;
        if (g_menuVisible && g_shell.pageT < 6.0f) g_shell.pageT += dt;

        // ── orb ────────────────────────────────────────────────────────────
        const bool boardVisible = g_shell.open > 0.03f;
        ax::Rect board = boardVisible ? ax::SettledPanel(disp, g_shell) : ax::MkRect(0, 0, 0, 0);
        if (ax::OrbFrame(apex::g_model, disp, dt, g_clock, g_orb, g_menuVisible, board)) {
            g_menuVisible = !g_menuVisible;
            if (g_menuVisible) g_shell.pageT = 0.0f;
        }

        if (hideViewSylphin3107) {
            hideViewSylphin3107.passTouchToContent = g_menuVisible;
            if (!g_menuVisible) {
                const CGFloat r = ax::kOrbRadius * 1.55f;
                hideViewSylphin3107.orbTouchRect =
                    CGRectMake(g_orb.pixel.x - r, g_orb.pixel.y - r, r * 2.0f, r * 2.0f);
            } else {
                hideViewSylphin3107.orbTouchRect = CGRectNull;
            }
        }

        // ── board ──────────────────────────────────────────────────────────
        if (boardVisible) {
            ax::ShellFrame(apex::g_model, disp, dt, g_clock, g_orb.pixel, g_shell);
            if (g_shell.closeNow) {
                g_menuVisible = false;
                g_shell.closeNow = false;
            }
        }

        // ── state that survives a relaunch ─────────────────────────────────
        g_uiTab    = g_shell.tab;
        g_uiOrbX   = g_orb.pos.x;
        g_uiOrbY   = g_orb.pos.y;
        g_uiPanelX = g_shell.offset.x;
        g_uiPanelY = g_shell.offset.y;

        ImGui::Render();
        ImGui_ImplMetal_RenderDrawData(ImGui::GetDrawData(), cb, enc);

        [enc popDebugGroup];
        [enc endEncoding];
        id<CAMetalDrawable> drawable = view.currentDrawable;
        if (drawable) [cb presentDrawable:drawable];
        [cb commit];
    }
}

@end
