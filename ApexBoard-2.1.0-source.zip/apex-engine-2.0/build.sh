#!/usr/bin/env bash
# ============================================================================
#  APEX ENGINE 2.1.0 — one command build
#    ./build.sh          release .deb + .dylib
#    ./build.sh debug    debug build (keeps symbols)
#  Requirements: Theos (THEOS exported) + iOS 14+ SDK under $THEOS/sdks
# ============================================================================
set -euo pipefail

MODE="${1:-release}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [ -z "${THEOS:-}" ]; then
  echo "!! THEOS is not set."
  echo "   export THEOS=~/theos          # macOS / Linux"
  echo "   install: https://theos.dev/docs/installation"
  exit 1
fi

if [ ! -d "$THEOS/makefiles" ]; then
  echo "!! \$THEOS ($THEOS) has no makefiles/ — point it at a real Theos checkout."
  exit 1
fi

if [ ! -d "$THEOS/sdks" ] || [ -z "$(ls -A "$THEOS/sdks" 2>/dev/null)" ]; then
  echo "!! no iOS SDK in $THEOS/sdks"
  echo "   put an iPhoneOS SDK there (e.g. iPhoneOS16.5.sdk) or run:"
  echo "   $THEOS/bin/install-sdk.sh"
  exit 1
fi

if [ "$MODE" = "debug" ]; then
  echo ">> debug build"
  make clean >/dev/null 2>&1 || true
  make DEBUG=1 FINALPACKAGE=0 package
else
  echo ">> release build"
  make clean >/dev/null 2>&1 || true
  make -j"$( (command -v nproc >/dev/null && nproc) || sysctl -n hw.ncpu 2>/dev/null || echo 4 )" package
fi

echo
echo "== artefacts =================================================="
ls -1 packages/*.deb 2>/dev/null || true
ls -1 .theos/obj/*/ApexBoard.dylib 2>/dev/null || true
echo "==============================================================="
echo "install : dpkg -i packages/*.deb    (or Filza / Sileo)"
echo "dylib   : cp .theos/obj/*/ApexBoard.dylib \\"
echo "          /var/jb/usr/lib/TweakInject/  (rootless)  + respring"
