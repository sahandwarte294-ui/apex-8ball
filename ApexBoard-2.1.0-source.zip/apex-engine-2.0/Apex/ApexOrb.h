// ============================================================================
//  APEX UI — ApexOrb.h
//  The launch surface: a draggable glass orb carrying the Apex mark.
//    · tap        -> open / close the board
//    · long press -> ghost it (near-invisible, still tappable)
//    · drag       -> follows the finger, docks to the nearest edge
//  Input is handled manually (no ImGui items) so the orb also works while the
//  board is closed and no window owns the hit test.
// ============================================================================
#pragma once

#include "ApexPrimitives.h"
#include "ApexModel.h"
#include "ApexWidgets.h"
#include "../ImGui/imgui_internal.h"

namespace ax {

struct OrbState {
    ImVec2 pos        = ImVec2(0.955f, 0.30f);  // normalised anchor
    ImVec2 pixel      = ImVec2(-1, -1);
    bool   dragging   = false;
    bool   moved      = false;
    float  pressTime  = 0.0f;
    float  ghost      = 0.0f;
    bool   ghosted    = false;
    float  flash      = 0.0f;
    bool   consume    = false;
    bool   ghostChanged = false;
    ImVec2 pressStart = ImVec2(0, 0);
};

constexpr float kOrbRadius = 30.0f;

// Returns true when the orb was tapped and the shell should toggle.
inline bool OrbFrame(const Model& m, ImVec2 display, float dt, float time, OrbState& o,
                     bool menuOpen, Rect blocked) {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const ImGuiIO& io = ImGui::GetIO();
    const float R = kOrbRadius;

    o.ghost = Lerp(o.ghost, o.ghosted ? 1.0f : 0.0f, 1.0f - expf(-8.0f * dt));
    o.flash = fmaxf(0.0f, o.flash - dt * 1.9f);

    if (o.pixel.x < 0.0f) o.pixel = ImVec2(o.pos.x * display.x, o.pos.y * display.y);
    if (o.dragging && io.MouseDown[0]) {
        const ImVec2 mp = io.MousePos;
        if (fabsf(mp.x - o.pressStart.x) > 7.0f || fabsf(mp.y - o.pressStart.y) > 7.0f) o.moved = true;
        if (o.moved) {
            ImVec2 p(mp.x, mp.y);
            p.x = p.x < R ? R : (p.x > display.x - R ? display.x - R : p.x);
            p.y = p.y < R ? R : (p.y > display.y - R ? display.y - R : p.y);
            o.pixel = p;
        }
        o.pressTime += dt;
        if (o.pressTime > 0.60f && !o.moved && !o.ghostChanged) {
            o.ghosted      = !o.ghosted;
            o.ghostChanged = true;
            o.flash        = 1.0f;
        }
    } else if (!o.dragging) {
        const ImVec2 target(o.pos.x * display.x, o.pos.y * display.y);
        o.pixel = ImVec2(Lerp(o.pixel.x, target.x, 1.0f - expf(-13.0f * dt)),
                         Lerp(o.pixel.y, target.y, 1.0f - expf(-13.0f * dt)));
    }

    // ── hit test (skipped when the board covers the orb) ────────────────────
    const bool covered = blocked.W() > 0 &&
                         o.pixel.x > blocked.a.x && o.pixel.x < blocked.b.x &&
                         o.pixel.y > blocked.a.y && o.pixel.y < blocked.b.y;
    const float dist = sqrtf((io.MousePos.x - o.pixel.x) * (io.MousePos.x - o.pixel.x) +
                             (io.MousePos.y - o.pixel.y) * (io.MousePos.y - o.pixel.y));
    bool tapped = false;

    if (!covered) {
        if (io.MouseClicked[0] && dist < R * 1.45f) {
            o.dragging    = true;
            o.moved       = false;
            o.pressTime   = 0.0f;
            o.ghostChanged= false;
            o.pressStart  = io.MousePos;
        }
        if (o.dragging && !io.MouseDown[0]) {
            o.dragging = false;
            if (!o.moved && !o.ghostChanged) {
                tapped  = true;
                o.flash = 1.0f;
            }
            o.pos.x = (o.pixel.x < display.x * 0.5f) ? (R + 12.0f) / display.x
                                                     : 1.0f - (R + 12.0f) / display.x;
            float ny = o.pixel.y / display.y;
            o.pos.y = ny < 0.12f ? 0.12f : (ny > 0.88f ? 0.88f : ny);
        }
    } else if (o.dragging && !io.MouseDown[0]) {
        o.dragging = false;
    }

    const float press = Anim().Approach(ImHashStr("apex_orb_press"), (o.dragging && !o.moved) ? 1.0f : 0.0f,
                                        22.0f, dt);
    const float hov   = Anim().Approach(ImHashStr("apex_orb_hover"), (dist < R * 1.45f && !covered) ? 1.0f : 0.0f,
                                        14.0f, dt);
    const float baseA = 1.0f - 0.82f * o.ghost;
    const float alpha = baseA * (0.90f + 0.10f * hov);
    const float scale = (1.0f + 0.055f * hov) * (1.0f - 0.13f * press);
    const float rr    = R * scale;
    const ImVec2 c    = o.pixel;

    // ── halo / breathing pulse ──────────────────────────────────────────────
    GlowDot(dl, c, rr * 2.7f, gold::Base, 0.30f * alpha * (0.62f + 0.38f * Pulse(time, 0.26f)));
    if (menuOpen) GlowDot(dl, c, rr * 2.0f, gold::Hi, 0.24f * alpha);

    for (int i = 0; i < 2; ++i) {
        const float ph  = fmodf(time * 0.5f + i * 0.5f, 1.0f);
        const float rad = rr * (1.05f + ph * 1.25f);
        const float al  = (1.0f - ph) * (1.0f - ph) * 0.32f * alpha;
        dl->AddCircle(c, rad, Fade(gold::Base, al), 44, 1.2f);
    }
    if (o.flash > 0.0f) {
        const float ph = 1.0f - o.flash;
        dl->AddCircle(c, rr * (1.0f + ph * 1.7f), Fade(gold::Hi, o.flash * 0.55f * alpha), 48, 1.6f);
    }

    // ── rotating arc set ────────────────────────────────────────────────────
    const float rot = time * 0.9f;
    for (int i = 0; i < 3; ++i) {
        const float a0 = rot + i * 2.0944f;
        dl->PathArcTo(c, rr * 1.32f, a0, a0 + 0.95f, 20);
        dl->PathStroke(Fade(gold::Base, 0.55f * alpha), 0, 1.4f);
    }

    // ── glass disc ──────────────────────────────────────────────────────────
    dl->AddCircleFilled(ImVec2(c.x, c.y + 2.2f), rr, C(0, 0, 0, (int)(95 * alpha)), 44);
    for (int i = 0; i < 16; ++i) {
        const float t = (float)i / 15.0f;
        const ImU32 col = Mix(C(41, 44, 56, (int)(246 * alpha)), C(11, 12, 16, (int)(246 * alpha)), t);
        dl->AddCircleFilled(ImVec2(c.x, c.y), rr * (1.0f - t * 0.14f), col, 44);
    }
    dl->AddCircle(c, rr, Fade(gold::Base, 0.72f * alpha), 52, 1.4f);
    dl->AddCircle(ImVec2(c.x, c.y - 0.8f), rr * 0.90f, Fade(C(255, 255, 255, 26), alpha), 48, 1.0f);
    dl->PathArcTo(c, rr * 0.78f, 3.40f, 5.30f, 18);
    dl->PathStroke(Fade(C(255, 255, 255, 62), alpha), 0, 2.2f);

    // ── mark ────────────────────────────────────────────────────────────────
    if (m.logoTexture) {
        const float s = rr * 1.30f;
        dl->AddImage(m.logoTexture, ImVec2(c.x - s * 0.5f, c.y - s * 0.5f),
                     ImVec2(c.x + s * 0.5f, c.y + s * 0.5f), ImVec2(0, 0), ImVec2(1, 1),
                     Fade(Mix(gold::Tint, gold::Hi, 0.30f + 0.30f * hov), alpha));
    } else {
        TextTrackedCentered(dl, ImVec2(c.x, c.y + 1.0f), 17.0f, 1.0f, Fade(gold::Tint, alpha), "A");
    }
    if (o.ghosted)
        dl->AddCircleFilled(c, rr * 1.02f, C(0, 0, 0, (int)(70 * o.ghost * alpha)), 40);

    return tapped;
}

} // namespace ax
