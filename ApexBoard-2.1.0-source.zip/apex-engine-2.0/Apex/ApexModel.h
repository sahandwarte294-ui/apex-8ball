// ============================================================================
//  APEX UI — ApexModel.h
//  The contract between the engine and the interface. The interface never
//  touches engine internals directly: it reads these pointers and reports
//  intents through ApexActions.
// ============================================================================
#pragma once

#include "ApexStyle.h"

namespace ax {

struct Telemetry {
    bool        booted      = false;
    bool        inGame      = false;
    bool        playerTurn  = false;
    bool        nineBall    = false;
    bool        callPocket  = false;
    int         gmState     = 0;
    int         mmState     = 0;
    int         balls       = 0;
    int         mode        = 0;
    int         fps         = 0;
    int         targetBall  = -1;
    int         targetPocket= -1;
    const char* modeName    = "--";
    const char* autoState   = "Idle";
    const char* ruleName    = "--";
    char        tablePtr[24]= {0};
};

struct Actions {
    void (*clearAutoplay)() = nullptr;
    void (*resetGeometry)() = nullptr;
    void (*saveLog)()       = nullptr;
    void (*panicHide)()     = nullptr;
};

struct Model {
    bool*  esp         = nullptr;
    bool*  predict     = nullptr;
    bool*  pockets     = nullptr;
    bool*  pocketState = nullptr;
    float* lineWidth   = nullptr;
    float* offsetX     = nullptr;
    float* offsetY     = nullptr;
    float* geomScale   = nullptr;
    bool*  autoAim     = nullptr;
    bool*  autoPlay    = nullptr;
    bool*  autoQueue   = nullptr;
    bool*  ghost       = nullptr;
    int*   tab         = nullptr;

    ImTextureID logoTexture = 0;   // Apex mark, premultiplied RGBA, ready to tint
    float       logoAspect  = 1.0f;

    Telemetry telemetry;
    Actions   actions;
};

} // namespace ax
