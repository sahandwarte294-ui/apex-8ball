// ============================================================================
//  APEX UI — ApexPrimitives.h
//  Low level painters: rounded gradients, layered soft shadows, glow, tracked
//  type, hairlines and the vector icon set. Everything is draw-list only.
// ============================================================================
#pragma once

#include "ApexStyle.h"
#include "../ImGui/imgui_internal.h"

namespace ax {

// ---------------------------------------------------------------------------
//  Vertex-coloured triangle (the glue for real gradients on rounded shapes)
// ---------------------------------------------------------------------------
inline void GradTri(ImDrawList* dl, ImVec2 p0, ImU32 c0, ImVec2 p1, ImU32 c1,
                    ImVec2 p2, ImU32 c2) {
    const ImVec2 uv = dl->_Data->TexUvWhitePixel;
    dl->PrimReserve(3, 3);
    const ImDrawIdx base = (ImDrawIdx)dl->_VtxCurrentIdx;
    dl->PrimWriteVtx(p0, uv, c0);
    dl->PrimWriteVtx(p1, uv, c1);
    dl->PrimWriteVtx(p2, uv, c2);
    dl->PrimWriteIdx(base);
    dl->PrimWriteIdx((ImDrawIdx)(base + 1));
    dl->PrimWriteIdx((ImDrawIdx)(base + 2));
}

// Rounded-rect outline sample points, clockwise, starting at top-left corner end.
inline int RoundRectPath(ImVec2 a, ImVec2 b, float r, ImVec2* out, int maxPts,
                         int cornerSeg = 5) {
    if (r > (b.x - a.x) * 0.5f) r = (b.x - a.x) * 0.5f;
    if (r > (b.y - a.y) * 0.5f) r = (b.y - a.y) * 0.5f;
    int n = 0;
    const ImVec2 c[4] = {ImVec2(a.x + r, a.y + r), ImVec2(b.x - r, a.y + r),
                         ImVec2(b.x - r, b.y - r), ImVec2(a.x + r, b.y - r)};
    const float start[4] = {3.14159265f, 4.71238898f, 0.0f, 1.57079633f};
    for (int k = 0; k < 4; ++k) {
        for (int s = 0; s <= cornerSeg; ++s) {
            if (n >= maxPts) return n;
            float ang = start[k] + (1.57079633f * s) / (float)cornerSeg;
            out[n++] = ImVec2(c[k].x + cosf(ang) * r, c[k].y + sinf(ang) * r);
        }
    }
    return n;
}

// Vertical gradient rounded rectangle (fan tessellation — shapes are convex).
inline void GradRoundRect(ImDrawList* dl, ImVec2 a, ImVec2 b, float r,
                          ImU32 topCol, ImU32 botCol) {
    if (b.x <= a.x || b.y <= a.y) return;
    ImVec2 pts[28];
    const int n = RoundRectPath(a, b, r, pts, 28, 4);
    if (n < 3) return;
    const float h = (b.y - a.y);
    auto colorAt = [&](float y) { return Mix(topCol, botCol, (y - a.y) / h); };
    const ImVec2 ctr((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
    const ImU32 cCtr = colorAt(ctr.y);
    for (int i = 0; i < n; ++i) {
        const ImVec2& p0 = pts[i];
        const ImVec2& p1 = pts[(i + 1) % n];
        GradTri(dl, ctr, cCtr, p0, colorAt(p0.y), p1, colorAt(p1.y));
    }
}

// Horizontal gradient rounded rectangle.
inline void GradRoundRectH(ImDrawList* dl, ImVec2 a, ImVec2 b, float r,
                           ImU32 leftCol, ImU32 rightCol) {
    if (b.x <= a.x || b.y <= a.y) return;
    ImVec2 pts[28];
    const int n = RoundRectPath(a, b, r, pts, 28, 4);
    if (n < 3) return;
    const float w = (b.x - a.x);
    auto colorAt = [&](float x) { return Mix(leftCol, rightCol, (x - a.x) / w); };
    const ImVec2 ctr((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
    const ImU32 cCtr = colorAt(ctr.x);
    for (int i = 0; i < n; ++i) {
        const ImVec2& p0 = pts[i];
        const ImVec2& p1 = pts[(i + 1) % n];
        GradTri(dl, ctr, cCtr, p0, colorAt(p0.x), p1, colorAt(p1.x));
    }
}

// ---------------------------------------------------------------------------
//  Soft elevation shadow: stacked rounded rects with decaying alpha.
// ---------------------------------------------------------------------------
inline void SoftShadow(ImDrawList* dl, ImVec2 a, ImVec2 b, float r,
                       float spread, float strength, float dy = 0.0f) {
    const int layers = 7;
    for (int i = layers; i >= 1; --i) {
        const float t = (float)i / (float)layers;
        const float g = spread * t;
        const float alpha = strength * (1.0f - t) * (1.0f - t) * 0.55f;
        if (alpha <= 0.004f) continue;
        dl->AddRectFilled(ImVec2(a.x - g, a.y - g + dy * t),
                          ImVec2(b.x + g, b.y + g + dy * t),
                          C(0, 0, 0, (int)(alpha * 255.0f)), r + g);
    }
}

// Radial glow built from concentric filled circles.
inline void GlowDot(ImDrawList* dl, ImVec2 c, float radius, ImU32 col, float strength) {
    const int steps = 10;
    for (int i = steps; i >= 1; --i) {
        const float t = (float)i / (float)steps;
        const float rr = radius * t;
        const float a = strength * (1.0f - t) * (1.0f - t) * 0.9f;
        if (a <= 0.004f) continue;
        dl->AddCircleFilled(c, rr, Fade(col, a), 36);
    }
}

// ---------------------------------------------------------------------------
//  Type
// ---------------------------------------------------------------------------
inline float TextWidth(float size, const char* s) {
    if (!s || !*s) return 0.0f;
    return ImGui::GetFont()->CalcTextSizeA(size, FLT_MAX, 0.0f, s).x;
}

inline float TrackedWidth(float size, float tracking, const char* s) {
    if (!s || !*s) return 0.0f;
    float w = 0.0f;
    for (const char* p = s; *p; ++p) {
        char buf[2] = {*p, 0};
        w += TextWidth(size, buf) + tracking;
    }
    return w > 0 ? w - tracking : 0.0f;
}

inline void Text(ImDrawList* dl, ImVec2 p, float size, ImU32 col, const char* s) {
    if (!s || !*s) return;
    dl->AddText(ImGui::GetFont(), size, ImVec2(p.x, p.y), col, s);
}

// Letter-spaced uppercase — the house style for labels and the wordmark.
inline void TextTracked(ImDrawList* dl, ImVec2 p, float size, float tracking,
                        ImU32 col, const char* s) {
    if (!s) return;
    float x = p.x;
    for (const char* c = s; *c; ++c) {
        char buf[2] = {*c, 0};
        dl->AddText(ImGui::GetFont(), size, ImVec2(x, p.y), col, buf);
        x += TextWidth(size, buf) + tracking;
    }
}

inline void TextTrackedCentered(ImDrawList* dl, ImVec2 center, float size, float tracking,
                                ImU32 col, const char* s) {
    const float w = TrackedWidth(size, tracking, s);
    TextTracked(dl, ImVec2(center.x - w * 0.5f, center.y - size * 0.62f), size, tracking, col, s);
}

inline void TextRight(ImDrawList* dl, ImVec2 rightBaseline, float size, ImU32 col, const char* s) {
    const float w = TextWidth(size, s);
    Text(dl, ImVec2(rightBaseline.x - w, rightBaseline.y), size, col, s);
}

// One pixel hairline with a soft horizontal fade at both ends.
inline void Hairline(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col, float fade = 0.0f) {
    if (fade <= 0.0f) {
        dl->AddLine(a, b, col, 1.0f);
        return;
    }
    const int seg = 24;
    for (int i = 0; i < seg; ++i) {
        float t0 = (float)i / seg, t1 = (float)(i + 1) / seg;
        float edge = 1.0f - (fabsf((t0 + t1) * 0.5f - 0.5f) * 2.0f);
        float alpha = Clamp01(edge / fade);
        ImU32 c = Fade(col, (float)Chan(col, 24) / 255.0f * alpha);
        dl->AddLine(ImVec2(Lerp(a.x, b.x, t0), Lerp(a.y, b.y, t0)),
                    ImVec2(Lerp(a.x, b.x, t1), Lerp(a.y, b.y, t1)), c, 1.0f);
    }
}

// ---------------------------------------------------------------------------
//  Vector icon set — drawn, not font glyphs, so it stays crisp at any scale.
// ---------------------------------------------------------------------------
enum IconId {
    ICON_PREDICT = 0,
    ICON_POCKET,
    ICON_CROSSHAIR,
    ICON_QUEUE,
    ICON_SHIELD,
    ICON_GAUGE,
    ICON_POWER,
    ICON_LOG,
    ICON_RESET,
};

inline void VectorIcon(ImDrawList* dl, int id, ImVec2 c, float s, ImU32 col, float thick) {
    const float h = s * 0.5f;
    switch (id) {
    case ICON_PREDICT: {  // dashed trajectory with target ball
        for (int i = 0; i < 3; ++i) {
            float y = c.y - h * 0.55f + i * h * 0.55f;
            dl->AddLine(ImVec2(c.x - h, y), ImVec2(c.x + h * 0.35f, y), Fade(col, 0.9f - i * 0.22f), thick);
        }
        dl->AddCircle(ImVec2(c.x + h * 0.72f, c.y + h * 0.55f), h * 0.30f, col, 14, thick);
        break;
    }
    case ICON_POCKET: {
        dl->AddCircle(ImVec2(c.x - h * 0.62f, c.y - h * 0.5f), h * 0.26f, col, 12, thick);
        dl->AddCircle(ImVec2(c.x + h * 0.62f, c.y - h * 0.5f), h * 0.26f, col, 12, thick);
        dl->AddCircle(ImVec2(c.x - h * 0.62f, c.y + h * 0.5f), h * 0.26f, col, 12, thick);
        dl->AddCircle(ImVec2(c.x + h * 0.62f, c.y + h * 0.5f), h * 0.26f, col, 12, thick);
        break;
    }
    case ICON_CROSSHAIR: {
        dl->AddCircle(c, h * 0.62f, col, 22, thick);
        dl->AddCircleFilled(c, h * 0.10f, col, 8);
        dl->AddLine(ImVec2(c.x, c.y - h), ImVec2(c.x, c.y - h * 0.72f), col, thick);
        dl->AddLine(ImVec2(c.x, c.y + h * 0.72f), ImVec2(c.x, c.y + h), col, thick);
        dl->AddLine(ImVec2(c.x - h, c.y), ImVec2(c.x - h * 0.72f, c.y), col, thick);
        dl->AddLine(ImVec2(c.x + h * 0.72f, c.y), ImVec2(c.x + h, c.y), col, thick);
        break;
    }
    case ICON_QUEUE: {
        dl->AddRectFilled(ImVec2(c.x - h, c.y - h * 0.62f), ImVec2(c.x + h * 0.15f, c.y - h * 0.18f), col, 1.5f);
        dl->AddRectFilled(ImVec2(c.x - h, c.y + h * 0.18f), ImVec2(c.x + h * 0.15f, c.y + h * 0.62f), Fade(col, 0.55f), 1.5f);
        dl->AddTriangleFilled(ImVec2(c.x + h * 0.42f, c.y - h * 0.34f), ImVec2(c.x + h * 0.42f, c.y + h * 0.34f),
                              ImVec2(c.x + h, c.y), col);
        break;
    }
    case ICON_SHIELD: {
        dl->AddBezierCubic(ImVec2(c.x - h * 0.72f, c.y - h * 0.62f), ImVec2(c.x - h * 0.3f, c.y - h * 0.8f),
                           ImVec2(c.x + h * 0.3f, c.y - h * 0.8f), ImVec2(c.x + h * 0.72f, c.y - h * 0.62f),
                           col, thick);
        dl->AddBezierCubic(ImVec2(c.x + h * 0.72f, c.y - h * 0.62f), ImVec2(c.x + h * 0.66f, c.y + h * 0.2f),
                           ImVec2(c.x + h * 0.3f, c.y + h * 0.62f), ImVec2(c.x, c.y + h * 0.85f),
                           col, thick);
        dl->AddBezierCubic(ImVec2(c.x, c.y + h * 0.85f), ImVec2(c.x - h * 0.3f, c.y + h * 0.62f),
                           ImVec2(c.x - h * 0.66f, c.y + h * 0.2f), ImVec2(c.x - h * 0.72f, c.y - h * 0.62f),
                           col, thick);
        break;
    }
    case ICON_GAUGE: {
        dl->PathArcTo(c, h * 0.78f, 3.14159265f, 6.2831853f, 22);
        dl->PathStroke(col, 0, thick);
        dl->AddLine(c, ImVec2(c.x + h * 0.45f, c.y - h * 0.45f), col, thick);
        break;
    }
    case ICON_POWER: {
        dl->AddCircle(c, h * 0.72f, col, 24, thick);
        dl->AddLine(ImVec2(c.x, c.y - h * 0.78f), ImVec2(c.x, c.y + h * 0.05f), col, thick * 1.15f);
        break;
    }
    case ICON_LOG: {
        for (int i = 0; i < 3; ++i) {
            float y = c.y - h * 0.55f + i * h * 0.55f;
            dl->AddLine(ImVec2(c.x - h * 0.8f, y), ImVec2(c.x + (i == 1 ? h * 0.2f : h * 0.8f), y), col, thick);
        }
        break;
    }
    case ICON_RESET: {
        dl->PathArcTo(c, h * 0.66f, 0.7f, 5.1f, 20);
        dl->PathStroke(col, 0, thick);
        dl->AddTriangleFilled(ImVec2(c.x + h * 0.86f, c.y - h * 0.40f),
                              ImVec2(c.x + h * 0.30f, c.y - h * 0.50f),
                              ImVec2(c.x + h * 0.60f, c.y + h * 0.10f), col);
        break;
    }
    default: break;
    }
}

} // namespace ax
