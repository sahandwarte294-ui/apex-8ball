// ============================================================================
//  APEX UI — ApexWidgets.h
//  Custom-drawn control set: card, section label, toggle row, precision slider,
//  layered 3D button, segmented rail, telemetry chip.
// ============================================================================
#pragma once

#include "ApexPrimitives.h"
#include "ApexModel.h"

namespace ax {

struct Rect {
    ImVec2 a, b;
    float  W() const { return b.x - a.x; }
    float  H() const { return b.y - a.y; }
    ImVec2 Center() const { return ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f); }
};

inline Rect MkRect(float x, float y, float w, float h) {
    return Rect{ImVec2(x, y), ImVec2(x + w, y + h)};
}

// Shared drawing context for one page worth of content.
struct Ctx {
    ImDrawList*  dl    = nullptr;
    const Model* m     = nullptr;
    float        zoom  = 1.0f;
    float        alpha = 1.0f;
    float        x     = 0.0f;   // content left
    float        y     = 0.0f;   // running cursor
    float        w     = 0.0f;   // content width
    float        t     = 0.0f;   // wall clock seconds
    float        pageT = 0.0f;   // seconds since this page became visible
    int          block = 0;      // stagger counter
    int          page  = 0;

    float Reveal() {
        const float delay = block * 0.035f;
        ++block;
        return EaseOutCubic((pageT - delay) / 0.30f);
    }
};

// ---------------------------------------------------------------------------
//  Card surface
// ---------------------------------------------------------------------------
inline void CardSurface(Ctx& cx, Rect r, float reveal, float radius = 17.0f) {
    if (reveal <= 0.001f) return;
    ImDrawList* dl = cx.dl;
    const float a = cx.alpha * reveal;
    const float dy = (1.0f - reveal) * 10.0f * cx.zoom;
    const ImVec2 p0(r.a.x, r.a.y + dy), p1(r.b.x, r.b.y + dy);

    SoftShadow(dl, p0, p1, radius, 24.0f * cx.zoom, 0.55f * a, 9.0f * cx.zoom);
    GradRoundRect(dl, p0, p1, radius, Fade(ink::CardTop, a), Fade(ink::CardBot, a));
    // glass sheen on the upper half
    GradRoundRect(dl, ImVec2(p0.x + 1, p0.y + 1),
                  ImVec2(p1.x - 1, p0.y + r.H() * 0.55f), radius - 1.0f,
                  Fade(C(255, 255, 255, 13), a), Fade(C(255, 255, 255, 0), a));
    dl->AddRect(p0, p1, Fade(ink::CardLine, a), radius, 0, 1.0f);
    // bright top edge
    dl->AddRect(ImVec2(p0.x, p0.y), ImVec2(p1.x, p0.y + 1.0f), Fade(C(255, 255, 255, 34), a),
                radius, ImDrawFlags_RoundCornersTop, 1.0f);
}

// Card title row: small tracked caption + optional right side text.
inline float CardTitle(Ctx& cx, Rect r, float reveal, const char* title, const char* right = nullptr,
                       ImU32 accent = gold::Base) {
    ImDrawList* dl = cx.dl;
    const float a = cx.alpha * reveal;
    const float pad = 14.0f * cx.zoom;
    const float yy = r.a.y + 11.0f * cx.zoom;
    // accent tick
    dl->AddRectFilled(ImVec2(r.a.x + pad, yy + 1.5f * cx.zoom),
                      ImVec2(r.a.x + pad + 2.0f * cx.zoom, yy + 9.5f * cx.zoom),
                      Fade(accent, a), 1.0f * cx.zoom);
    TextTracked(dl, ImVec2(r.a.x + pad + 8.0f * cx.zoom, yy), 8.6f * cx.zoom, 2.2f * cx.zoom,
                Fade(txt::Mute, a), title);
    if (right) {
        TextRight(dl, ImVec2(r.b.x - pad, yy + 0.5f * cx.zoom), 8.6f * cx.zoom, Fade(txt::Ghost, a), right);
    }
    return yy + 18.0f * cx.zoom;
}

// ---------------------------------------------------------------------------
//  Input plumbing
// ---------------------------------------------------------------------------
struct HitState {
    bool hovered = false;
    bool held    = false;
    bool clicked = false;
};

inline HitState Probe(Ctx& cx, const char* id, Rect r) {
    HitState h;
    ImGui::SetCursorScreenPos(r.a);
    ImGui::InvisibleButton(id, ImVec2(r.W() > 1 ? r.W() : 1, r.H() > 1 ? r.H() : 1),
                           ImGuiButtonFlags_MouseButtonLeft);
    h.hovered = ImGui::IsItemHovered();
    h.held    = ImGui::IsItemActive();
    h.clicked = ImGui::IsItemDeactivated() && ImGui::IsItemHovered();
    return h;
}

// ---------------------------------------------------------------------------
//  Toggle switch (capsule + travelling knob + gold halo)
// ---------------------------------------------------------------------------
inline void PaintSwitch(Ctx& cx, ImVec2 origin, float width, float t, float alpha, float hover) {
    ImDrawList* dl = cx.dl;
    const float z = cx.zoom;
    const float w = width * z;
    const float h = w * 0.553f;
    const ImVec2 a = origin, b(a.x + w, a.y + h);
    const float rad = h * 0.5f;

    if (t > 0.01f)
        GlowDot(dl, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), h * 1.45f, gold::Base,
                0.22f * t * alpha);

    GradRoundRect(dl, a, b, rad,
                  Fade(Mix(C(34, 36, 45), gold::Base, t * 0.9f), alpha),
                  Fade(Mix(C(18, 19, 25), gold::Deep, t * 0.92f), alpha));
    dl->AddRect(a, b, Fade(Mix(C(255, 255, 255, 26), gold::Hi, t), alpha * (0.45f + 0.35f * hover)),
                rad, 0, 1.0f);

    const float kx = a.x + rad + t * (w - h);
    const float kr = rad - 3.2f * z;
    const ImVec2 kc(kx, (a.y + b.y) * 0.5f);
    dl->AddCircleFilled(ImVec2(kc.x, kc.y + 1.8f * z), kr, C(0, 0, 0, (int)(80 * alpha)), 26);
    dl->AddCircleFilled(kc, kr, Fade(Mix(C(226, 231, 240), C(255, 251, 240), t), alpha), 26);
    dl->AddCircleFilled(ImVec2(kc.x, kc.y - kr * 0.28f), kr * 0.66f,
                        Fade(Mix(C(255, 255, 255, 46), C(255, 255, 255, 96), t), alpha * 0.55f), 20);
}

// Row: icon tile + label + sub-label + switch, whole row is the hit target.
inline bool ToggleRow(Ctx& cx, const char* id, float y, float height, bool value,
                      const char* label, const char* sub, int iconId, float reveal) {
    const float z = cx.zoom, pad = 14.0f * z;
    Rect r = MkRect(cx.x + pad, y, cx.w - pad * 2.0f, height * z);
    const float a = cx.alpha * reveal;
    HitState hs = Probe(cx, id, r);
    const ImGuiID aid = ImGui::GetID(id);
    const float on = Anim().Approach(aid + 1, value ? 1.0f : 0.0f, 18.0f, ImGui::GetIO().DeltaTime);
    const float hov = Anim().Approach(aid + 2, hs.hovered ? 1.0f : 0.0f, 14.0f, ImGui::GetIO().DeltaTime);

    if (hov > 0.01f)
        GradRoundRect(cx.dl, ImVec2(r.a.x - 8 * z, r.a.y), ImVec2(r.b.x + 8 * z, r.b.y), 11 * z,
                      Fade(C(255, 255, 255, 10), a * hov), Fade(C(255, 255, 255, 2), a * hov));

    // icon tile
    const float tile = 27.0f * z;
    Rect ir = MkRect(r.a.x, r.a.y + (r.H() - tile) * 0.5f, tile, tile);
    GradRoundRect(cx.dl, ir.a, ir.b, 8.5f * z, Fade(C(255, 255, 255, 14), a), Fade(C(255, 255, 255, 5), a));
    cx.dl->AddRect(ir.a, ir.b, Fade(C(255, 255, 255, 16), a), 8.5f * z, 0, 1.0f);
    VectorIcon(cx.dl, iconId, ir.Center(), 15.0f * z, Fade(Mix(txt::Mute, gold::Tint, on), a), 1.35f * z);

    const float textX = ir.b.x + 11.0f * z;
    const float sw = 44.0f * z;
    const float swX = r.b.x - sw;
    if (sub && *sub) {
        Text(cx.dl, ImVec2(textX, r.a.y + r.H() * 0.5f - 14.0f * z), 12.4f * z,
             Fade(Mix(txt::Body, txt::Hi, on * 0.55f), a), label);
        Text(cx.dl, ImVec2(textX, r.a.y + r.H() * 0.5f + 3.0f * z), 8.8f * z, Fade(txt::Ghost, a), sub);
    } else {
        Text(cx.dl, ImVec2(textX, r.a.y + (r.H() - 12.4f * z) * 0.5f - 1.0f * z), 12.4f * z,
             Fade(Mix(txt::Body, txt::Hi, on * 0.55f), a), label);
    }
    PaintSwitch(cx, ImVec2(swX, r.a.y + (r.H() - 44.0f * z * 0.553f) * 0.5f), 44.0f, on, a, hov);
    return hs.clicked;
}

// ---------------------------------------------------------------------------
//  Precision slider with value chip
// ---------------------------------------------------------------------------
inline bool SliderRow(Ctx& cx, const char* id, float y, bool integer, bool showSign,
                      const char* label, float* value, float vmin, float vmax,
                      float step, float reveal) {
    const float z = cx.zoom, pad = 14.0f * z;
    Rect r = MkRect(cx.x + pad, y, cx.w - pad * 2.0f, 44.0f * z);
    const float a = cx.alpha * reveal;
    HitState hs = Probe(cx, id, r);
    const ImGuiID aid = ImGui::GetID(id);
    const float hov = Anim().Approach(aid + 2, hs.hovered ? 1.0f : 0.0f, 16.0f, ImGui::GetIO().DeltaTime);

    const float trackY = r.a.y + 26.0f * z;
    const float trackH = 4.0f * z;
    const float knobR  = 6.4f * z;
    Rect track = MkRect(r.a.x, trackY, r.W(), trackH);

    float t = (vmax > vmin) ? (*value - vmin) / (vmax - vmin) : 0.0f;
    t = Clamp01(t);

    if (hs.held) {
        float m = (ImGui::GetIO().MousePos.x - track.a.x) / (track.W() > 1 ? track.W() : 1);
        m = Clamp01(m);
        float nv = vmin + m * (vmax - vmin);
        if (step > 0.0f) nv = vmin + floorf((nv - vmin) / step + 0.5f) * step;
        *value = nv < vmin ? vmin : (nv > vmax ? vmax : nv);
        t = Clamp01((*value - vmin) / (vmax - vmin));
    }

    // label + value chip
    TextTracked(cx.dl, ImVec2(r.a.x, r.a.y + 2.0f * z), 9.0f * z, 1.6f * z, Fade(txt::Mute, a), label);
    char buf[32];
    if (integer) snprintf(buf, sizeof(buf), "%s%d", showSign && *value > 0 ? "+" : "", (int)(*value + 0.5f));
    else         snprintf(buf, sizeof(buf), "%s%.2f", showSign && *value > 0 ? "+" : "", *value);
    const float chipW = TextWidth(9.0f * z, buf) + 12.0f * z;
    Rect chip = MkRect(r.b.x - chipW, r.a.y - 1.0f * z, chipW, 17.0f * z);
    GradRoundRect(cx.dl, chip.a, chip.b, 6.0f * z, Fade(C(255, 255, 255, 12), a), Fade(C(255, 255, 255, 4), a));
    Text(cx.dl, ImVec2(chip.a.x + 6.0f * z, chip.a.y + 3.2f * z), 9.0f * z, Fade(gold::Tint, a), buf);

    // track
    GradRoundRect(cx.dl, track.a, track.b, trackH * 0.5f, Fade(ink::WellTop, a), Fade(ink::WellBot, a));
    cx.dl->AddRect(track.a, track.b, Fade(C(255, 255, 255, 10), a), trackH * 0.5f, 0, 1.0f);
    if (t > 0.001f) {
        Rect fill = MkRect(track.a.x, track.a.y, track.W() * t, track.H());
        GlowDot(cx.dl, ImVec2(fill.b.x, fill.Center().y), trackH * 2.6f, gold::Base, 0.35f * a);
        GradRoundRectH(cx.dl, fill.a, fill.b, trackH * 0.5f, Fade(gold::Deep, a), Fade(gold::Hi, a));
    }
    // knob
    ImVec2 kc(track.a.x + track.W() * t, track.Center().y);
    cx.dl->AddCircleFilled(ImVec2(kc.x, kc.y + 1.2f * z), knobR + 0.6f * z, C(0, 0, 0, (int)(90 * a)), 20);
    cx.dl->AddCircleFilled(kc, knobR, Fade(Mix(C(240, 243, 249), gold::Hi, hov), a), 20);
    if (hs.held || hov > 0.5f)
        cx.dl->AddCircle(kc, knobR + 3.4f * z, Fade(gold::Base, a * 0.45f), 20, 1.2f * z);
    return hs.held;
}

// ---------------------------------------------------------------------------
//  Layered 3D button
// ---------------------------------------------------------------------------
inline bool Button3D(Ctx& cx, const char* id, Rect r, const char* label, int iconId,
                     bool primary, float reveal, bool enabled = true) {
    const float z = cx.zoom;
    const float a = cx.alpha * reveal * (enabled ? 1.0f : 0.45f);
    HitState hs = Probe(cx, id, r);
    const ImGuiID aid = ImGui::GetID(id);
    const float hov = Anim().Approach(aid + 2, (hs.hovered && enabled) ? 1.0f : 0.0f, 16.0f,
                                      ImGui::GetIO().DeltaTime);
    const float press = Anim().Approach(aid + 3, (hs.held && enabled) ? 1.0f : 0.0f, 26.0f,
                                        ImGui::GetIO().DeltaTime);
    const float lift = -1.2f * z * hov + 2.2f * z * press;
    ImVec2 p0 = ImVec2(r.a.x, r.a.y + lift), p1 = ImVec2(r.b.x, r.b.y + lift);
    const float rad = 11.0f * z;

    SoftShadow(cx.dl, p0, p1, rad, 14.0f * z, (0.5f - 0.34f * press) * a, (5.0f - 3.0f * press) * z);

    ImU32 top, bot, edge, textCol;
    if (primary) {
        top  = Mix(gold::Hi, gold::Base, 0.42f + 0.2f * press);
        bot  = Mix(gold::Base, gold::Deep, 0.72f + 0.2f * press);
        edge = Mix(gold::Hi, C(255, 255, 255, 200), hov * 0.45f);
        textCol = txt::OnGold;
    } else {
        top  = Mix(C(44, 47, 58), C(34, 36, 45), press);
        bot  = Mix(C(24, 26, 33), C(17, 18, 24), press);
        edge = Fade(C(255, 255, 255, 40), 1.0f + hov * 0.4f);
        textCol = Mix(txt::Hi, gold::Hi, hov * 0.5f);
    }
    GradRoundRect(cx.dl, p0, p1, rad, Fade(top, a), Fade(bot, a));
    // inner top gloss
    GradRoundRect(cx.dl, ImVec2(p0.x + 1.2f * z, p0.y + 1.0f * z),
                  ImVec2(p1.x - 1.2f * z, p0.y + (p1.y - p0.y) * 0.52f), rad - 1.0f * z,
                  Fade(C(255, 255, 255, primary ? 70 : 22), a), Fade(C(255, 255, 255, 0), a));
    cx.dl->AddRect(p0, p1, Fade(edge, a * 0.85f), rad, 0, 1.0f);

    const float ih = 13.0f * z;
    const float tw = TextWidth(11.0f * z, label) + (iconId >= 0 ? ih + 8.0f * z : 0.0f);
    float x = p0.x + (p1.x - p0.x - tw) * 0.5f;
    const float cy = (p0.y + p1.y) * 0.5f;
    if (iconId >= 0) {
        VectorIcon(cx.dl, iconId, ImVec2(x + ih * 0.5f, cy), ih, Fade(textCol, a), 1.3f * z);
        x += ih + 8.0f * z;
    }
    Text(cx.dl, ImVec2(x, cy - 11.0f * z * 0.5f - 1.2f * z), 11.0f * z, Fade(textCol, a), label);
    return hs.clicked && enabled;
}

// ---------------------------------------------------------------------------
//  Segmented rail with a travelling gold indicator
// ---------------------------------------------------------------------------
inline int Rail(Ctx& cx, const char* id, Rect r, const char* const* labels, int count,
                int active, float reveal) {
    const float z = cx.zoom, a = cx.alpha * reveal;
    // rail bed
    GradRoundRect(cx.dl, r.a, r.b, r.H() * 0.5f, Fade(C(9, 10, 13, 200), a), Fade(C(18, 19, 25, 200), a));
    cx.dl->AddRect(r.a, r.b, Fade(C(255, 255, 255, 9), a), r.H() * 0.5f, 0, 1.0f);

    const float segW = r.W() / (float)count;
    ImGuiID aid = ImGui::GetID(id);
    float& ind = Anim().Ref(aid + 7);
    if (ind <= 0.0001f && active > 0) ind = (float)active;
    ind = Lerp(ind, (float)active, 1.0f - expf(-14.0f * ImGui::GetIO().DeltaTime));

    Rect indR = MkRect(r.a.x + segW * ind + 3.0f * z, r.a.y + 3.0f * z,
                       segW - 6.0f * z, r.H() - 6.0f * z);
    GlowDot(cx.dl, indR.Center(), indR.H() * 1.15f, gold::Base, 0.30f * a);
    GradRoundRect(cx.dl, indR.a, indR.b, indR.H() * 0.5f, Fade(gold::Hi, a), Fade(gold::Base, a));
    GradRoundRect(cx.dl, ImVec2(indR.a.x + 1, indR.a.y + 1),
                  ImVec2(indR.b.x - 1, indR.a.y + indR.H() * 0.5f), indR.H() * 0.5f - 1,
                  Fade(C(255, 255, 255, 80), a), Fade(C(255, 255, 255, 0), a));

    int changed = -1;
    for (int i = 0; i < count; ++i) {
        Rect sr = MkRect(r.a.x + segW * i, r.a.y, segW, r.H());
        char wid[24];
        snprintf(wid, sizeof(wid), "%s_%d", id, i);
        HitState hs = Probe(cx, wid, sr);
        const float sel = 1.0f - Clamp01(fabsf(ind - (float)i));
        ImU32 col = Mix(txt::Mute, txt::OnGold, sel);
        if (hs.hovered && sel < 0.6f) col = Mix(col, txt::Hi, 0.5f);
        TextTrackedCentered(cx.dl, sr.Center(), 9.4f * z, 2.0f * z, Fade(col, a), labels[i]);
        if (hs.clicked) changed = i;
    }
    return changed;
}

// ---------------------------------------------------------------------------
//  Telemetry chip
// ---------------------------------------------------------------------------
inline void StatChip(Ctx& cx, Rect r, const char* label, const char* value, ImU32 dot) {
    const float z = cx.zoom, a = cx.alpha;
    GradRoundRect(cx.dl, r.a, r.b, 10.0f * z, Fade(C(255, 255, 255, 10), a), Fade(C(255, 255, 255, 3), a));
    cx.dl->AddRect(r.a, r.b, Fade(C(255, 255, 255, 12), a), 10.0f * z, 0, 1.0f);
    const float pad = 9.0f * z;
    cx.dl->AddCircleFilled(ImVec2(r.a.x + pad + 2.5f * z, r.Center().y), 2.6f * z, Fade(dot, a), 12);
    TextTracked(cx.dl, ImVec2(r.a.x + pad + 10.0f * z, r.a.y + 5.0f * z), 7.4f * z, 1.4f * z,
                Fade(txt::Ghost, a), label);
    Text(cx.dl, ImVec2(r.a.x + pad + 10.0f * z, r.a.y + 13.5f * z), 10.8f * z, Fade(txt::Hi, a), value);
}

// ---------------------------------------------------------------------------
//  Key / value diagnostic line
// ---------------------------------------------------------------------------
inline void DiagLine(Ctx& cx, Rect r, const char* k, const char* v, ImU32 vcol = txt::Body) {
    const float z = cx.zoom, a = cx.alpha;
    Text(cx.dl, ImVec2(r.a.x, r.a.y + 3.0f * z), 9.6f * z, Fade(txt::Mute, a), k);
    TextRight(cx.dl, ImVec2(r.b.x, r.a.y + 3.0f * z), 9.6f * z, Fade(vcol, a), v);
}

} // namespace ax
