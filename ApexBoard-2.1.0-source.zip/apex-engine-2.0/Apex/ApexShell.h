// ============================================================================
//  APEX UI — ApexShell.h
//  The board. Header, segmented rail, four pages, footer, and the open/close
//  choreography (bloom from the orb, staggered card reveals, sheen sweep).
// ============================================================================
#pragma once

#include "ApexPrimitives.h"
#include "ApexModel.h"
#include "ApexWidgets.h"

namespace ax {

static const float kPanelW = 384.0f;
static const float kPanelH = 612.0f;

// Header drag plumbing, filled by DrawHeader, consumed by ShellFrame.
inline ImVec2& DragDelta() { static ImVec2 v(0, 0); return v; }
inline float&  SwipeDown() { static float v = 0.0f; return v; }

struct ShellState {
    bool   visible   = false;
    float  open      = 0.0f;      // 0..1 animation driver
    float  pageT     = 9.0f;
    int    tab       = 0;
    int    shownTab  = 0;
    ImVec2 offset    = ImVec2(0, 0);
    bool   dragging  = false;
    float  dragAcc    = 0.0f;
    bool   closeNow  = false;
    float  sheen     = 0.0f;
};

// ---------------------------------------------------------------------------
//  Shared bits
// ---------------------------------------------------------------------------
inline void PanelChrome(ImDrawList* dl, ImVec2 a, ImVec2 b, float radius, float alpha,
                        float sheenT) {
    SoftShadow(dl, a, b, radius, 46.0f, 0.72f * alpha, 14.0f);
    GradRoundRect(dl, a, b, radius, Fade(ink::ShellTop, alpha), Fade(ink::ShellBot, alpha));
    // ambient top light
    GradRoundRect(dl, ImVec2(a.x + 1, a.y + 1), ImVec2(b.x - 1, a.y + 150.0f), radius - 1,
                  Fade(C(255, 255, 255, 16), alpha), Fade(C(255, 255, 255, 0), alpha));
    // bottom inner shade
    GradRoundRect(dl, ImVec2(a.x + 1, b.y - 110.0f), ImVec2(b.x - 1, b.y - 1), radius - 1,
                  Fade(C(0, 0, 0, 0), alpha), Fade(C(0, 0, 0, 70), alpha));
    dl->AddRect(a, b, Fade(C(255, 255, 255, 26), alpha), radius, 0, 1.0f);
    dl->AddRect(ImVec2(a.x, a.y), ImVec2(b.x, a.y + 1.2f), Fade(C(255, 255, 255, 54), alpha),
                radius, ImDrawFlags_RoundCornersTop, 1.2f);

    if (sheenT > 0.0f && sheenT < 1.0f) {
        const float sweep = Lerp(a.x - 90.0f, b.x + 90.0f, EaseInOutCubic(sheenT));
        dl->PushClipRect(a, b, true);
        GradRoundRectH(dl, ImVec2(sweep - 46.0f, a.y), ImVec2(sweep + 46.0f, b.y), 0.0f,
                       Fade(C(255, 255, 255, 0), alpha), Fade(C(255, 236, 200, 16), alpha));
        dl->PopClipRect();
    }
}

// ---------------------------------------------------------------------------
//  Header
// ---------------------------------------------------------------------------
inline void DrawHeader(Ctx& cx, Rect panel, const Telemetry& tm, bool* wantClose) {
    ImDrawList* dl = cx.dl;
    const float z = cx.zoom, a = cx.alpha;
    const float pad = 16.0f * z;

    const float tile = 44.0f * z;
    Rect logo = MkRect(panel.a.x + pad, panel.a.y + 16.0f * z, tile, tile);
    GradRoundRect(dl, logo.a, logo.b, 13.0f * z, Fade(C(58, 46, 26, 240), a), Fade(C(23, 21, 17, 240), a));
    dl->AddRect(logo.a, logo.b, Fade(gold::Base, a * 0.55f), 13.0f * z, 0, 1.2f);
    // gold corner glints
    dl->PathArcTo(logo.Center(), tile * 0.36f, 3.35f, 5.05f, 16);
    dl->PathStroke(Fade(gold::Hi, a * 0.30f), 0, 1.4f);

    if (cx.m->logoTexture) {
        const float s = tile * 0.74f;
        dl->AddImage(cx.m->logoTexture, ImVec2(logo.Center().x - s * 0.5f, logo.Center().y - s * 0.5f),
                     ImVec2(logo.Center().x + s * 0.5f, logo.Center().y + s * 0.5f),
                     ImVec2(0, 0), ImVec2(1, 1), Fade(gold::Tint, a));
    } else {
        TextTrackedCentered(dl, ImVec2(logo.Center().x, logo.Center().y + 2.0f * z), 17.0f * z, 1.0f * z,
                            Fade(gold::Tint, a), "A");
    }

    // wordmark
    const float wx = logo.b.x + 12.0f * z;
    TextTracked(dl, ImVec2(wx, panel.a.y + 19.0f * z), 24.0f * z, 6.0f * z, Fade(C(247, 243, 234), a), "APEX");
    dl->AddRectFilled(ImVec2(wx + 1.0f * z, panel.a.y + 50.0f * z),
                      ImVec2(wx + 58.0f * z, panel.a.y + 51.4f * z), Fade(gold::Base, a * 0.75f), 1.0f);
    TextTracked(dl, ImVec2(wx + 64.0f * z, panel.a.y + 45.5f * z), 8.2f * z, 2.4f * z,
                Fade(txt::Mute, a), "8-BALL SUITE");

    // status pill
    const char* label = tm.inGame ? "IN MATCH" : (tm.booted ? "STANDBY" : "BOOTING");
    ImU32 dot = tm.inGame ? SigGood : (tm.booted ? SigWarn : SigBad);
    const float pw = 78.0f * z;
    Rect pill = MkRect(panel.b.x - pad - pw, panel.a.y + 22.0f * z, pw, 24.0f * z);
    GradRoundRect(dl, pill.a, pill.b, 12.0f * z, Fade(C(255, 255, 255, 9), a), Fade(C(255, 255, 255, 3), a));
    dl->AddRect(pill.a, pill.b, Fade(C(255, 255, 255, 14), a), 12.0f * z, 0, 1.0f);
    GlowDot(dl, ImVec2(pill.a.x + 12.0f * z, pill.Center().y), 6.0f * z, dot, 0.55f * a);
    dl->AddCircleFilled(ImVec2(pill.a.x + 12.0f * z, pill.Center().y), 2.2f * z, Fade(dot, a), 12);
    TextTracked(dl, ImVec2(pill.a.x + 20.0f * z, pill.Center().y - 4.6f * z), 7.6f * z, 1.3f * z,
                Fade(txt::Body, a), label);

    // close button (drawn before the drag strip so it wins the hover)
    Rect cb = MkRect(panel.b.x - pad - 26.0f * z - pw - 10.0f * z, panel.a.y + 22.0f * z, 26.0f * z, 26.0f * z);
    HitState hs = Probe(cx, "##apex_close", cb);
    const float hov = Anim().Approach(ImGui::GetID("##apex_close") + 3, hs.hovered ? 1.0f : 0.0f, 14.0f,
                                      ImGui::GetIO().DeltaTime);
    dl->AddCircleFilled(cb.Center(), cb.W() * 0.5f, Fade(C(255, 255, 255, 6 + (int)(12 * hov)), a), 22);
    dl->AddCircle(cb.Center(), cb.W() * 0.5f, Fade(C(255, 255, 255, 18 + (int)(40 * hov)), a), 22, 1.0f);
    const float cr = 4.6f * z;
    const ImVec2 cc = cb.Center();
    const float ang = hov * 1.5707963f;
    const ImVec2 u(cosf(ang) * cr, sinf(ang) * cr), v(-sinf(ang) * cr, cosf(ang) * cr);
    ImU32 ccol = Mix(txt::Mute, txt::Hi, hov);
    dl->AddLine(ImVec2(cc.x - u.x - v.x, cc.y - u.y - v.y), ImVec2(cc.x + u.x + v.x, cc.y + u.y + v.y),
                Fade(ccol, a), 1.5f * z);
    dl->AddLine(ImVec2(cc.x - u.x + v.x, cc.y - u.y + v.y), ImVec2(cc.x + u.x - v.x, cc.y + u.y - v.y),
                Fade(ccol, a), 1.5f * z);
    if (hs.clicked) *wantClose = true;

    // drag strip (whole header; drawn last so the close button keeps priority)
    Rect drag = MkRect(panel.a.x + pad, panel.a.y + 6.0f * z,
                       (panel.b.x - pad - 4.0f * z) - (panel.a.x + pad), 62.0f * z);
    Probe(cx, "##apex_drag", drag);
    if (ImGui::IsItemActive() && ImGui::GetIO().MouseDown[0]) {
        ImVec2 d = ImGui::GetIO().MouseDelta;
        DragDelta() = d;
        if (d.y > 0.0f) SwipeDown() += d.y;
    }
    // header hairline
    Hairline(dl, ImVec2(panel.a.x + 18.0f * z, panel.a.y + 76.0f * z),
             ImVec2(panel.b.x - 18.0f * z, panel.a.y + 76.0f * z), Fade(C(255, 255, 255, 22), a), 0.55f);
}

// ---------------------------------------------------------------------------
//  Pages
// ---------------------------------------------------------------------------
inline void PageDash(Ctx& cx, const Model& m) {
    const float z = cx.zoom, P = 16.0f * z;
    const float w = cx.w;
    const Telemetry& tm = m.telemetry;

    // ── hero ────────────────────────────────────────────────────────────────
    {
        float rv = cx.Reveal();
        Rect hero = MkRect(cx.x + P, cx.y, w - P * 2, 112.0f * z);
        CardSurface(cx, hero, rv);
        const float a = cx.alpha * rv;

        if (m.logoTexture) {
            const float s = 132.0f * z;
            cx.dl->PushClipRect(hero.a, hero.b, true);
            cx.dl->AddImage(m.logoTexture, ImVec2(hero.b.x - s + 14.0f * z, hero.a.y + 6.0f * z),
                            ImVec2(hero.b.x + 14.0f * z, hero.a.y + s + 6.0f * z), ImVec2(0, 0), ImVec2(1, 1),
                            Fade(gold::Tint, a * 0.075f));
            cx.dl->PopClipRect();
        }
        TextTracked(cx.dl, ImVec2(hero.a.x + 16.0f * z, hero.a.y + 15.0f * z), 8.2f * z, 2.4f * z,
                    Fade(txt::Mute, a), "AIM ENGINE");

        const char* state = *m.esp ? "ARMED" : "SAFE";
        TextTracked(cx.dl, ImVec2(hero.a.x + 15.0f * z, hero.a.y + 32.0f * z), 27.0f * z, 2.0f * z,
                    Fade(*m.esp ? gold::Hi : txt::Hi, a), state);
        Text(cx.dl, ImVec2(hero.a.x + 16.0f * z, hero.a.y + 70.0f * z), 8.8f * z, Fade(txt::Ghost, a),
             *m.esp ? "trajectory solver live  /  v2.1.0" : "engine parked  /  tap master to arm");

        // master switch
        const float swW = 52.0f * z;
        Rect swR = MkRect(hero.b.x - swW - 16.0f * z, hero.a.y + 44.0f * z, swW, 40.0f * z);
        HitState hs = Probe(cx, "##master", swR);
        const float on = Anim().Approach(ImGui::GetID("##master") + 1, *m.esp ? 1.0f : 0.0f, 16.0f,
                                         ImGui::GetIO().DeltaTime);
        const float hov = Anim().Approach(ImGui::GetID("##master") + 2, hs.hovered ? 1.0f : 0.0f, 14.0f,
                                          ImGui::GetIO().DeltaTime);
        PaintSwitch(cx, ImVec2(swR.a.x, swR.a.y + 4.0f * z), 52.0f, on, a, hov);
        TextTracked(cx.dl, ImVec2(swR.a.x, swR.a.y + 34.0f * z), 7.2f * z, 1.6f * z, Fade(txt::Ghost, a), "MASTER");
        if (hs.clicked && m.esp) *m.esp = !*m.esp;
        cx.y += 112.0f * z + 12.0f * z;
    }

    // ── quick tiles ─────────────────────────────────────────────────────────
    {
        const float gap = 10.0f * z;
        const float tw = (w - P * 2 - gap) * 0.5f;
        const float th = 70.0f * z;
        struct Tile { const char* id; const char* label; int icon; bool* v; };
        const Tile tiles[4] = {
            {"##t_pred",  "PREDICTION", ICON_PREDICT,   m.predict},
            {"##t_pock",  "POCKETS",    ICON_POCKET,    m.pockets},
            {"##t_aim",   "AUTO AIM",   ICON_CROSSHAIR, m.autoAim},
            {"##t_queue", "AUTO QUEUE", ICON_QUEUE,     m.autoQueue},
        };
        float rv0 = cx.Reveal();
        float rv1 = cx.Reveal();
        for (int i = 0; i < 4; ++i) {
            const int col = i % 2, row = i / 2;
            Rect t = MkRect(cx.x + P + col * (tw + gap), cx.y + row * (th + gap), tw, th);
            const float rv = col == 0 ? rv0 : rv1;
            const float a = cx.alpha * rv;
            const float on = Anim().Approach(ImGui::GetID(tiles[i].id) + 1, *tiles[i].v ? 1.0f : 0.0f, 16.0f,
                                             ImGui::GetIO().DeltaTime);
            HitState hs = Probe(cx, tiles[i].id, t);
            const float hov = Anim().Approach(ImGui::GetID(tiles[i].id) + 2, hs.hovered ? 1.0f : 0.0f, 14.0f,
                                              ImGui::GetIO().DeltaTime);
            const float dy = (1.0f - rv) * 10.0f * z - 1.0f * z * hov;
            Rect tt = MkRect(t.a.x, t.a.y + dy, t.W(), t.H());
            SoftShadow(cx.dl, tt.a, tt.b, 14.0f * z, 16.0f * z, 0.45f * a, 6.0f * z);
            GradRoundRect(cx.dl, tt.a, tt.b, 14.0f * z,
                          Fade(Mix(C(34, 36, 46), C(64, 50, 26), on * 0.9f), a),
                          Fade(Mix(C(19, 20, 26), C(30, 25, 16), on * 0.9f), a));
            cx.dl->AddRect(tt.a, tt.b, Fade(Mix(C(255, 255, 255, 20), gold::Base, on * 0.65f), a),
                           14.0f * z, 0, 1.0f);
            if (on > 0.02f)
                GlowDot(cx.dl, ImVec2(tt.a.x + 24.0f * z, tt.a.y + 24.0f * z), 26.0f * z, gold::Base, 0.22f * on * a);

            VectorIcon(cx.dl, tiles[i].icon, ImVec2(tt.a.x + 22.0f * z, tt.a.y + 24.0f * z), 18.0f * z,
                       Fade(Mix(txt::Mute, gold::Tint, on), a), 1.4f * z);
            TextTracked(cx.dl, ImVec2(tt.a.x + 12.0f * z, tt.b.y - 22.0f * z), 8.8f * z, 1.7f * z,
                        Fade(Mix(txt::Body, txt::Hi, on * 0.6f), a), tiles[i].label);
            PaintSwitch(cx, ImVec2(tt.b.x - 40.0f * z, tt.a.y + 14.0f * z), 30.0f, on, a, hov);
            if (hs.clicked) *tiles[i].v = !*tiles[i].v;
        }
        cx.y += th * 2.0f + gap + 12.0f * z;
    }

    // ── telemetry chips ─────────────────────────────────────────────────────
    {
        const float rv = cx.Reveal();
        const float gap = 8.0f * z;
        const float cw = (w - P * 2 - gap * 2) * (1.0f / 3.0f);
        char fps[16], balls[16], st[24];
        snprintf(fps, sizeof(fps), "%d", (int)tm.fps);
        snprintf(balls, sizeof(balls), "%d", tm.balls);
        snprintf(st, sizeof(st), "%s", tm.playerTurn ? "YOUR TURN" : (tm.inGame ? "WAITING" : "IDLE"));
        StatChip(cx, MkRect(cx.x + P, cx.y, cw, 46.0f * z), "FPS", fps,
                 tm.fps > 45 ? SigGood : SigWarn);
        StatChip(cx, MkRect(cx.x + P + cw + gap, cx.y, cw, 46.0f * z), "ON TABLE", balls, SigCool);
        StatChip(cx, MkRect(cx.x + P + (cw + gap) * 2, cx.y, cw, 46.0f * z), "STATUS", st,
                 tm.playerTurn ? SigGood : SigWarn);
        cx.y += 46.0f * z + 12.0f * z;
        (void)rv;
    }

    // ── session card ────────────────────────────────────────────────────────
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 84.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "SESSION", tm.ruleName);
        const float lx = card.a.x + 14.0f * z, rx = card.b.x - 14.0f * z;
        char tb[24] = "--";
        if (tm.targetBall >= 0) snprintf(tb, sizeof(tb), "%d -> %d", tm.targetBall, tm.targetPocket);
        DiagLine(cx, MkRect(lx, card.a.y + 30.0f * z, rx - lx, 16.0f * z), "CURRENT SHOT", tb,
                 tm.targetBall >= 0 ? gold::Tint : txt::Ghost);
        DiagLine(cx, MkRect(lx, card.a.y + 47.0f * z, rx - lx, 16.0f * z), "AUTOPLAY", tm.autoState,
                 txt::Body);
        DiagLine(cx, MkRect(lx, card.a.y + 64.0f * z, rx - lx, 16.0f * z), "TABLE", tm.tablePtr,
                 txt::Mute);
        cx.y += 84.0f * z;
    }
}

inline void PageAim(Ctx& cx, const Model& m) {
    const float z = cx.zoom, P = 16.0f * z, w = cx.w;
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 160.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "VISION");
        float y = card.a.y + 28.0f * z;
        if (ToggleRow(cx, "##v_pred", y, 42.0f, *m.predict, "Prediction Line",
                      "ball path + cushion reflection", ICON_PREDICT, rv)) *m.predict = !*m.predict;
        y += 42.0f * z;
        if (ToggleRow(cx, "##v_pock", y, 42.0f, *m.pockets, "Pocket Overlay",
                      "target rings on all six pockets", ICON_POCKET, rv)) *m.pockets = !*m.pockets;
        y += 42.0f * z;
        if (ToggleRow(cx, "##v_state", y, 42.0f, *m.pocketState, "Pocket State",
                      "highlights the called pocket", ICON_CROSSHAIR, rv)) *m.pocketState = !*m.pocketState;
        cx.y += 160.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 202.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "GEOMETRY");
        float y = card.a.y + 28.0f * z;
        SliderRow(cx, "##s_lw", y, false, false, "LINE WIDTH", m.lineWidth, 0.5f, 5.0f, 0.1f, rv);
        y += 42.0f * z;
        SliderRow(cx, "##s_ox", y, false, true, "OFFSET X", m.offsetX, -50.0f, 50.0f, 0.5f, rv);
        y += 42.0f * z;
        SliderRow(cx, "##s_oy", y, false, true, "OFFSET Y", m.offsetY, -50.0f, 50.0f, 0.5f, rv);
        y += 42.0f * z;
        SliderRow(cx, "##s_sc", y, false, false, "SCALE", m.geomScale, 0.900f, 1.100f, 0.001f, rv);
        cx.y += 202.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        Rect b = MkRect(cx.x + P, cx.y, w - P * 2, 40.0f * z);
        if (Button3D(cx, "##btn_reset_geo", b, "RESET GEOMETRY", ICON_RESET, false, rv)) {
            if (m.actions.resetGeometry) m.actions.resetGeometry();
        }
        cx.y += 40.0f * z;
    }
}

inline void PageAuto(Ctx& cx, const Model& m) {
    const float z = cx.zoom, P = 16.0f * z, w = cx.w;
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 180.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "AUTOPILOT", m.telemetry.autoState);
        float y = card.a.y + 28.0f * z;
        if (ToggleRow(cx, "##a_aim", y, 46.0f, *m.autoAim, "Auto Aim",
                      "rotate the cue onto the solved line", ICON_CROSSHAIR, rv)) *m.autoAim = !*m.autoAim;
        y += 46.0f * z;
        if (ToggleRow(cx, "##a_play", y, 46.0f, *m.autoPlay, "Autoplay",
                      "scan, select and strike autonomously", ICON_POWER, rv)) *m.autoPlay = !*m.autoPlay;
        y += 50.0f * z;
        Rect btn = MkRect(card.a.x + 14.0f * z, y, card.W() - 28.0f * z, 44.0f * z);
        const bool running = *m.autoPlay;
        if (Button3D(cx, "##a_run", btn, running ? "STOP SESSION" : "START SESSION",
                     running ? ICON_POWER : ICON_GAUGE, !running, rv)) {
            if (m.autoPlay) *m.autoPlay = !*m.autoPlay;
            if (!running && m.actions.clearAutoplay) m.actions.clearAutoplay();
        }
        cx.y += 180.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 100.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "SOLVER");
        const float lx = card.a.x + 14.0f * z, rx = card.b.x - 14.0f * z;
        DiagLine(cx, MkRect(lx, card.a.y + 32.0f * z, rx - lx, 16.0f * z), "STATE", m.telemetry.autoState, txt::Body);
        DiagLine(cx, MkRect(lx, card.a.y + 50.0f * z, rx - lx, 16.0f * z), "CALL POCKET",
                 m.telemetry.callPocket ? "EVERY SHOT" : "NORMAL", txt::Body);
        DiagLine(cx, MkRect(lx, card.a.y + 68.0f * z, rx - lx, 16.0f * z), "RULE",
                 m.telemetry.nineBall ? "9-BALL" : "8-BALL", gold::Tint);
        cx.y += 100.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 102.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "REMATCH QUEUE");
        if (ToggleRow(cx, "##a_queue", card.a.y + 26.0f * z, 46.0f, *m.autoQueue, "Auto Queue",
                      "re-enter the table automatically", ICON_QUEUE, rv)) *m.autoQueue = !*m.autoQueue;
        DiagLine(cx, MkRect(card.a.x + 14.0f * z, card.a.y + 76.0f * z, card.W() - 28.0f * z, 16.0f * z),
                 "MODE", m.telemetry.modeName, txt::Mute);
        cx.y += 102.0f * z;
    }
}

inline void PageSys(Ctx& cx, const Model& m) {
    const float z = cx.zoom, P = 16.0f * z, w = cx.w;
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 96.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "STEALTH", "SCREENSHOT GUARD");
        if (ToggleRow(cx, "##s_ghost", card.a.y + 26.0f * z, 46.0f, *m.ghost, "Hide From Capture",
                      "menu and overlay stay off recordings", ICON_SHIELD, rv)) *m.ghost = !*m.ghost;
        cx.y += 96.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 136.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "TELEMETRY", m.telemetry.booted ? "LINKED" : "NO LINK");
        const float lx = card.a.x + 14.0f * z, rx = card.b.x - 14.0f * z;
        char b1[32], b2[32], b3[32];
        snprintf(b1, sizeof(b1), "%d / %d", m.telemetry.gmState, m.telemetry.mmState);
        snprintf(b2, sizeof(b2), "%d", m.telemetry.mode);
        snprintf(b3, sizeof(b3), "%s", m.telemetry.modeName);
        DiagLine(cx, MkRect(lx, card.a.y + 32.0f * z, rx - lx, 16.0f * z), "STATE GM / MM", b1);
        DiagLine(cx, MkRect(lx, card.a.y + 50.0f * z, rx - lx, 16.0f * z), "GAME MODE", b2);
        DiagLine(cx, MkRect(lx, card.a.y + 68.0f * z, rx - lx, 16.0f * z), "MODE NAME", b3, gold::Tint);
        DiagLine(cx, MkRect(lx, card.a.y + 86.0f * z, rx - lx, 16.0f * z), "TABLE", m.telemetry.tablePtr,
                 txt::Mute);
        DiagLine(cx, MkRect(lx, card.a.y + 104.0f * z, rx - lx, 16.0f * z), "RENDER",
                 m.telemetry.fps > 45 ? "SMOOTH" : "THROTTLED",
                 m.telemetry.fps > 45 ? SigGood : SigWarn);
        cx.y += 136.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        Rect card = MkRect(cx.x + P, cx.y, w - P * 2, 78.0f * z);
        CardSurface(cx, card, rv);
        CardTitle(cx, card, rv, "TOOLKIT");
        const float gap = 8.0f * z;
        const float bw = (card.W() - 28.0f * z - gap) * 0.5f;
        Rect b1 = MkRect(card.a.x + 14.0f * z, card.a.y + 26.0f * z, bw, 40.0f * z);
        Rect b2 = MkRect(b1.b.x + gap, b1.a.y, bw, 40.0f * z);
        if (Button3D(cx, "##sys_log", b1, "EXPORT LOG", ICON_LOG, false, rv) && m.actions.saveLog)
            m.actions.saveLog();
        if (Button3D(cx, "##sys_hide", b2, "HIDE PANEL", ICON_SHIELD, false, rv) && m.actions.panicHide)
            m.actions.panicHide();
        cx.y += 78.0f * z + 10.0f * z;
    }
    {
        const float rv = cx.Reveal();
        const float a = cx.alpha * rv;
        TextTracked(cx.dl, ImVec2(cx.x + P, cx.y + 2.0f * z), 7.6f * z, 1.8f * z, Fade(txt::Ghost, a),
                    "APEX ENGINE 2.1.0  /  BUILT FOR 8 BALL POOL");
        Text(cx.dl, ImVec2(cx.x + P, cx.y + 16.0f * z), 8.4f * z, Fade(txt::Ghost, a * 0.9f),
             "Tap the orb to summon or dismiss the panel.");
        cx.y += 34.0f * z;
    }
}

// ---------------------------------------------------------------------------
//  Frame
// ---------------------------------------------------------------------------
inline Rect SettledPanel(ImVec2 display, const ShellState& st) {
    float fit = fminf(1.0f, (display.x - 18.0f) / kPanelW);
    fit = fminf(fit, (display.y - 18.0f) / kPanelH);
    const float W = kPanelW * fit, H = kPanelH * fit;
    ImVec2 t((display.x - W) * 0.5f + st.offset.x, (display.y - H) * 0.5f + st.offset.y);
    const float edge = 10.0f;
    t.x = t.x < edge ? edge : (t.x > display.x - W - edge ? display.x - W - edge : t.x);
    t.y = t.y < edge ? edge : (t.y > display.y - H - edge ? display.y - H - edge : t.y);
    return MkRect(t.x, t.y, W, H);
}

inline void ShellFrame(const Model& m, ImVec2 display, float dt, float time, ImVec2 bloomFrom,
                       ShellState& st) {
    // sizing: shrink to fit small screens
    float fit = fminf(1.0f, (display.x - 18.0f) / kPanelW);
    fit = fminf(fit, (display.y - 18.0f) / kPanelH);

    const float openE = EaseOutBack(st.open);
    const float zoom  = fit * (0.90f + 0.10f * openE);
    const float alpha = Clamp01(st.open * 1.35f);
    if (alpha <= 0.004f) return;

    const float W = kPanelW * zoom, H = kPanelH * zoom;

    ImVec2 target((display.x - W) * 0.5f + st.offset.x, (display.y - H) * 0.5f + st.offset.y);
    const float edge = 10.0f;
    target.x = target.x < edge ? edge : (target.x > display.x - W - edge ? display.x - W - edge : target.x);
    target.y = target.y < edge ? edge : (target.y > display.y - H - edge ? display.y - H - edge : target.y);

    const float bloom = EaseOutQuint(Clamp01(st.open * 1.6f));
    ImVec2 pos(Lerp(bloomFrom.x - W * 0.5f, target.x, bloom),
               Lerp(bloomFrom.y - H * 0.5f, target.y, bloom));

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(display);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::Begin("##apex_root", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                 ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
                 ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    Rect panel = MkRect(pos.x, pos.y, W, H);
    const float radius = 24.0f * zoom;

    st.sheen = fminf(1.0f, st.sheen + dt * 1.35f);
    PanelChrome(dl, panel.a, panel.b, radius, alpha, st.open < 0.98f ? st.sheen : 2.0f);

    Ctx cx;
    cx.dl = dl; cx.m = &m; cx.zoom = zoom; cx.alpha = alpha; cx.t = time;
    cx.pageT = st.pageT; cx.page = st.tab;

    // ── header ──────────────────────────────────────────────────────────────
    dl->PushClipRect(panel.a, ImVec2(panel.b.x, panel.a.y + 76.0f * zoom), true);
    bool wantClose = false;
    DrawHeader(cx, panel, m.telemetry, &wantClose);
    dl->PopClipRect();
    st.offset.x += DragDelta().x;
    st.offset.y += DragDelta().y;
    if (SwipeDown() > 84.0f && DragDelta().y > 0.0f) wantClose = true;
    DragDelta() = ImVec2(0, 0);
    if (!ImGui::GetIO().MouseDown[0]) SwipeDown() = 0.0f;

    // ── rail ────────────────────────────────────────────────────────────────
    static const char* kTabs[4] = {"DASH", "AIM", "AUTO", "SYS"};
    Rect rail = MkRect(panel.a.x + 16.0f * zoom, panel.a.y + 84.0f * zoom,
                       W - 32.0f * zoom, 34.0f * zoom);
    int changed = Rail(cx, "##apex_rail", rail, kTabs, 4, st.tab, Clamp01(st.open * 2.0f));
    if (changed >= 0 && changed != st.tab) {
        st.tab = changed;
        st.pageT = 0.0f;
        if (m.tab) *m.tab = changed;
    }

    // ── page body ───────────────────────────────────────────────────────────
    const float bodyTop = rail.b.y + 10.0f * zoom;
    const float bodyBot = panel.b.y - 44.0f * zoom;
    dl->PushClipRect(ImVec2(panel.a.x, bodyTop), ImVec2(panel.b.x, bodyBot), true);
    cx.x = panel.a.x;
    cx.y = bodyTop;
    cx.w = W;
    cx.pageT = st.pageT;
    cx.block = 0;
    switch (st.tab) {
        case 0: PageDash(cx, m); break;
        case 1: PageAim(cx, m);  break;
        case 2: PageAuto(cx, m); break;
        default: PageSys(cx, m); break;
    }
    dl->PopClipRect();

    // ── footer ──────────────────────────────────────────────────────────────
    {
        const float fy = panel.b.y - 30.0f * zoom;
        Hairline(dl, ImVec2(panel.a.x + 16.0f * zoom, panel.b.y - 38.0f * zoom),
                 ImVec2(panel.b.x - 16.0f * zoom, panel.b.y - 38.0f * zoom),
                 Fade(C(255, 255, 255, 18), alpha), 0.6f);
        dl->AddCircleFilled(ImVec2(panel.a.x + 20.0f * zoom, fy + 3.0f * zoom), 2.0f * zoom,
                            Fade(gold::Base, alpha * 0.9f), 10);
        TextTracked(dl, ImVec2(panel.a.x + 27.0f * zoom, fy - 1.0f * zoom), 7.4f * zoom, 1.9f * zoom,
                    Fade(txt::Ghost, alpha), "TAP ORB  /  DRAG HEADER  /  SWIPE DOWN");
        TextTracked(dl, ImVec2(panel.b.x - 52.0f * zoom, fy - 1.0f * zoom), 7.4f * zoom, 1.4f * zoom,
                    Fade(gold::Base, alpha * 0.8f), "v2.1");
    }

    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);

    if (wantClose) st.closeNow = true;
}

} // namespace ax
