// ============================================================================
//  APEX UI — ApexStyle.h
//  Design tokens, color helpers, easing curves and the animation clock.
//  Pure ImGui/STL: no UIKit, no Metal. Compiles on device and on desktop.
// ============================================================================
#pragma once

#include "../ImGui/imgui.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>

namespace ax {

// ---------------------------------------------------------------------------
//  Color utilities (ImU32 == 0xAABBGGRR)
// ---------------------------------------------------------------------------
constexpr ImU32 C(int r, int g, int b, int a = 255) {
    return ((ImU32)(a & 0xFF) << 24) | ((ImU32)(b & 0xFF) << 16) |
           ((ImU32)(g & 0xFF) << 8)  |  (ImU32)(r & 0xFF);
}

inline int  Chan(ImU32 c, int shift) { return (int)((c >> shift) & 0xFF); }

inline ImU32 Fade(ImU32 c, float a) {
    int na = (int)(Chan(c, 24) * (a < 0 ? 0 : (a > 1 ? 1 : a)) + 0.5f);
    return (c & 0x00FFFFFF) | ((ImU32)na << 24);
}

inline ImU32 Mix(ImU32 a, ImU32 b, float t) {
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    int r = (int)(Chan(a, 0) + (Chan(b, 0) - Chan(a, 0)) * t);
    int g = (int)(Chan(a, 8) + (Chan(b, 8) - Chan(a, 8)) * t);
    int bl= (int)(Chan(a, 16) + (Chan(b, 16) - Chan(a, 16)) * t);
    int al= (int)(Chan(a, 24) + (Chan(b, 24) - Chan(a, 24)) * t);
    return C(r, g, bl, al);
}

// ---------------------------------------------------------------------------
//  Palette — "obsidian + champagne gold"
// ---------------------------------------------------------------------------
namespace ink {
    constexpr ImU32 ShellTop    = C(20, 21, 27, 250);   // panel body, top
    constexpr ImU32 ShellBot    = C(9, 10, 13, 250);    // panel body, bottom
    constexpr ImU32 CardTop     = C(34, 36, 46, 238);
    constexpr ImU32 CardBot     = C(18, 19, 26, 238);
    constexpr ImU32 CardLine    = C(255, 255, 255, 16);
    constexpr ImU32 Hairline    = C(255, 255, 255, 12);
    constexpr ImU32 WellTop     = C(8, 9, 12, 210);
    constexpr ImU32 WellBot     = C(14, 15, 20, 210);
}

namespace gold {
    constexpr ImU32 Hi         = C(255, 231, 178);
    constexpr ImU32 Base       = C(233, 187, 112);
    constexpr ImU32 Deep       = C(191, 132, 48);
    constexpr ImU32 Shadow     = C(120, 74, 16);
    constexpr ImU32 Tint       = C(240, 196, 118);
}

namespace txt {
    constexpr ImU32 Hi         = C(242, 245, 250);
    constexpr ImU32 Body       = C(190, 197, 211);
    constexpr ImU32 Mute       = C(142, 151, 169);
    constexpr ImU32 Ghost      = C(108, 117, 133);
    constexpr ImU32 OnGold     = C(24, 19, 10);
}

constexpr ImU32 SigGood   = C(72, 216, 162);
constexpr ImU32 SigWarn   = C(255, 176, 74);
constexpr ImU32 SigBad    = C(255, 96, 104);
constexpr ImU32 SigCool   = C(104, 200, 255);

// ---------------------------------------------------------------------------
//  Easing
// ---------------------------------------------------------------------------
inline float Clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
inline float Lerp(float a, float b, float t) { return a + (b - a) * t; }

inline float EaseOutCubic(float t) {
    t = Clamp01(t) - 1.0f;
    return t * t * t + 1.0f;
}
inline float EaseInCubic(float t) {
    t = Clamp01(t);
    return t * t * t;
}
inline float EaseInOutCubic(float t) {
    t = Clamp01(t);
    return t < 0.5f ? 4.0f * t * t * t : 1.0f - powf(-2.0f * t + 2.0f, 3.0f) * 0.5f;
}
inline float EaseOutBack(float t) {
    t = Clamp01(t);
    const float c1 = 1.18f, c3 = c1 + 1.0f;
    float u = t - 1.0f;
    return 1.0f + c3 * u * u * u + c1 * u * u;
}
inline float EaseOutQuint(float t) { t = Clamp01(t); return 1.0f - powf(1.0f - t, 5.0f); }

inline float Pulse(float time, float hz) {
    return 0.5f + 0.5f * sinf(time * hz * 6.28318530718f);
}

// ---------------------------------------------------------------------------
//  Per-widget animation store.
//  Fixed slot table instead of std::map: -fno-exceptions friendly, zero malloc.
// ---------------------------------------------------------------------------
struct AnimSlot {
    ImGuiID id;
    float   value;
    float   target;
};

class AnimStore {
public:
    static const int kSlots = 640;
    AnimSlot slots[kSlots];
    int      used = 0;

    float& Ref(ImGuiID id) {
        for (int i = 0; i < used; ++i)
            if (slots[i].id == id) return slots[i].value;
        int idx = used < kSlots ? used++ : (int)(id % kSlots);
        slots[idx].id = id;
        slots[idx].value = 0.0f;
        slots[idx].target = 0.0f;
        return slots[idx].value;
    }

    // Frame-rate independent exponential approach.
    float Approach(ImGuiID id, float target, float speed, float dt) {
        float& v = Ref(id);
        float k = 1.0f - expf(-speed * dt);
        v += (target - v) * k;
        if (fabsf(target - v) < 0.0015f) v = target;
        return v;
    }
};

inline AnimStore& Anim() {
    static AnimStore store;
    return store;
}

// ---------------------------------------------------------------------------
//  Layout metrics (multiplied by the shell zoom factor)
// ---------------------------------------------------------------------------
struct Metrics {
    float scale;        // DPI / zoom multiplier
    float pad;          // outer padding
    float radius;       // panel radius
    float cardRadius;
    float gap;

    float S(float v) const { return v * scale; }
};

} // namespace ax
