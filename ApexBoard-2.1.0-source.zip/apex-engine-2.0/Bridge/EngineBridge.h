// ============================================================================
//  EngineBridge.h  —  the only place where the game engine and the interface
//  meet. Engine.h exposes state; Apex UI consumes a plain ApexModel. Nothing
//  in Apex/ knows what a GameManager is, and nothing in Engine.h knows what a
//  card looks like.
// ============================================================================
#pragma once

#import "../Core/Engine.h"
#include "../Apex/ApexModel.h"

namespace apex {

// ---------------------------------------------------------------------------
//  Live state shared with the interface
// ---------------------------------------------------------------------------
static ax::Model g_model;
static bool      g_menuOpen = false;

// ---------------------------------------------------------------------------
//  Actions the interface can trigger
// ---------------------------------------------------------------------------
inline void Act_ClearAutoplay() {
    AutoPlay::state = AutoPlay::IDLE;
    AutoPlay::pendingShotPower = 0.0;
    AutoPlay::pendingShotAngle = 0.0;
}

inline void Act_ResetGeometry() {
    g_tableOffsetX    = 0.0f;
    g_tableOffsetY    = 0.0f;
    g_tableScaleFactor = 1.0f;
    g_autoScaleOK      = false;
}

inline void Act_PanicHide() {
    g_menuOpen = false;
}

inline void Act_ExportLog() {
    @try {
        NSMutableString* log = [NSMutableString string];
        [log appendString:@"=== APEX ENGINE 2.1.0 // session report ===\n"];
        [log appendFormat:@"stamp       : %@\n", [NSDate date]];
        [log appendFormat:@"base        : 0x%llX  slide: 0x%lX\n",
                           (unsigned long long)g_poolBase, g_poolSlide];
        [log appendFormat:@"GameManager : 0x%llX\n", (unsigned long long)g_gameManager];
        [log appendFormat:@"UserInfo    : 0x%llX\n", (unsigned long long)g_userInfo];
        [log appendFormat:@"in game     : %d   player turn: %d\n", isInGame(), isPlayerTurn()];
        [log appendFormat:@"GM state    : %d   MM state: %d\n", g_cache.gmStateId, g_cache.mmStateId];
        [log appendFormat:@"mode        : %d (%s)\n", getRuntimeGameMode(), gameModeName(getRuntimeGameMode()));
        [log appendFormat:@"rule        : %s   call-pocket: %s\n",
                           isNineBallRuntime() ? "9-ball" : "8-ball",
                           isCallPocketEveryShotMode() ? "every shot" : "normal"];
        [log appendString:@"\n--- tables ---\n"];
        [log appendFormat:@"mTable            : 0x%lX\n", (long)g_off.gm_mTable];
        [log appendFormat:@"mVisualCue        : 0x%lX\n", (long)g_off.gm_mVisualCue];
        [log appendFormat:@"mVisualEnglish    : 0x%lX\n", (long)g_off.gm_mVisualEnglishControl];
        [log appendFormat:@"mStateManager     : 0x%lX\n", (long)g_off.gm_mStateManager];
        [log appendFormat:@"balls             : 0x%lX\n", (long)g_off.tbl_mBalls];

        ptr table = GM_Table();
        const int count = getTableBallCount(table);
        if (count > 0) {
            [log appendFormat:@"\n--- balls (%d) ---\n", count];
            for (int i = 0; i < count && i < 16; ++i) {
                ptr ball = getTableBall(table, i);
                if (!ball) continue;
                Vec2d p = ballPosition(ball);
                [log appendFormat:@"[%2d] pos=(%8.2f,%8.2f) class=%d state=%d\n",
                                   i, p.x, p.y, (int)ballClassification(ball), (int)ballState(ball)];
            }
        }
        [log appendFormat:@"\n--- settings ---\n"];
        [log appendFormat:@"esp=%d pred=%d pockets=%d pocketState=%d\n",
                           g_espEnabled, g_drawPredictionLine, g_drawPockets, g_drawPocketsShotState];
        [log appendFormat:@"line=%.2f offX=%.2f offY=%.2f scale=%.4f\n",
                           g_lineWidth, g_tableOffsetX, g_tableOffsetY, g_tableScaleFactor];
        [log appendFormat:@"autoAim=%d autoPlay=%d autoQueue=%d ghost=%d\n",
                           AutoPlay::bAutoAim, AutoPlay::bAutoPlaying, AutoQueue::bAutoQueue, g_noScreenShot];

        NSString* dir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        NSString* path = [dir stringByAppendingPathComponent:@"apex_session.log"];
        NSError* err = nil;
        [log writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&err];
        NSLog(@"[APEX] report -> %@ (err=%@)", path, err);
    } @catch (NSException* e) {
        NSLog(@"[APEX] report failed: %@", e);
    }
}

// ---------------------------------------------------------------------------
//  Bind once, refresh every frame
// ---------------------------------------------------------------------------
inline void Bind() {
    g_model.esp         = &g_espEnabled;
    g_model.predict     = &g_drawPredictionLine;
    g_model.pockets     = &g_drawPockets;
    g_model.pocketState = &g_drawPocketsShotState;
    g_model.lineWidth   = &g_lineWidth;
    g_model.offsetX     = &g_tableOffsetX;
    g_model.offsetY     = &g_tableOffsetY;
    g_model.geomScale   = &g_tableScaleFactor;
    g_model.autoAim     = &AutoPlay::bAutoAim;
    g_model.autoPlay    = &AutoPlay::bAutoPlaying;
    g_model.autoQueue   = &AutoQueue::bAutoQueue;
    g_model.ghost       = &g_noScreenShot;
    g_model.tab         = &g_uiTab;

    g_model.actions.clearAutoplay = &Act_ClearAutoplay;
    g_model.actions.resetGeometry = &Act_ResetGeometry;
    g_model.actions.saveLog       = &Act_ExportLog;
    g_model.actions.panicHide     = &Act_PanicHide;
}

inline const char* AutoStateName() {
    switch (AutoPlay::state) {
        case AutoPlay::SCANNING:   return "Scanning";
        case AutoPlay::SELECTING:  return "Selecting";
        case AutoPlay::NOMINATING: return "Calling";
        case AutoPlay::SHOOTING:   return "Striking";
        default: return AutoPlay::bAutoPlaying ? "Armed" : "Idle";
    }
}

inline void Refresh() {
    ax::Telemetry& tm = g_model.telemetry;
    tm.booted     = g_initialized && isValidPtr(g_gameManager);
    tm.inGame     = isInGame();
    tm.playerTurn = isPlayerTurn();
    tm.gmState    = g_cache.gmStateId;
    tm.mmState    = g_cache.mmStateId;
    tm.balls      = getTableBallCount(GM_Table());
    tm.mode       = getRuntimeGameMode();
    tm.modeName   = gameModeName(tm.mode);
    tm.nineBall   = isNineBallRuntime();
    tm.callPocket = isCallPocketEveryShotMode();
    tm.ruleName   = tm.nineBall ? "9-BALL" : "8-BALL";
    tm.autoState  = AutoStateName();
    tm.targetBall = g_CurrentCandidate.idx;
    tm.targetPocket = g_CurrentCandidate.pocketIndex;
    tm.fps        = (int)(ImGui::GetIO().Framerate + 0.5f);
    snprintf(tm.tablePtr, sizeof(tm.tablePtr), "0x%llX", (unsigned long long)GM_Table());
}

} // namespace apex
