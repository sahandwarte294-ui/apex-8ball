// APEX UI — offline render harness.
// Rasterises a real ImGui frame (ImDrawData) into a PNG so the shipped menu can
// be reviewed without a device. No GPU, no window, no drivers: pure CPU.
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "Apex/ApexStyle.h"
#include "Apex/ApexPrimitives.h"
#include "Apex/ApexWidgets.h"
#include "Apex/ApexModel.h"
#include "Apex/ApexShell.h"
#include "Apex/ApexOrb.h"
#include "ImGui/zzz.h"

#include <vector>
#include <string>
#include <cstdio>
#include <cmath>

// ---------------------------------------------------------------------------
// Canvas
// ---------------------------------------------------------------------------
struct Canvas {
    int w = 0, h = 0;
    std::vector<unsigned char> px;   // RGBA

    void Init(int W, int H, bool gameBg) {
        w = W; h = H;
        px.assign((size_t)w * h * 4, 0);
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                float ty = (float)y / h;
                float tx = (float)x / w;
                float r = 22.0f - 12.0f * ty, g = 24.0f - 13.0f * ty, b = 31.0f - 18.0f * ty;
                if (gameBg) {
                    // faint felt + spotlight, so the floating orb has context
                    float dx = tx - 0.5f, dy = ty - 0.56f;
                    float d = sqrtf(dx * dx * 1.6f + dy * dy);
                    float spot = fmaxf(0.0f, 1.0f - d * 1.7f);
                    r += 6.0f * spot + 4.0f * fmaxf(0.0f, 0.6f - fabsf(ty - 0.62f));
                    g += 14.0f * spot + 12.0f * fmaxf(0.0f, 0.6f - fabsf(ty - 0.62f));
                    b += 12.0f * spot + 6.0f * fmaxf(0.0f, 0.6f - fabsf(ty - 0.62f));
                }
                float vig = 1.0f - 0.35f * (sqrtf((tx - .5f) * (tx - .5f) + (ty - .5f) * (ty - .5f)) * 1.5f);
                unsigned char* p = &px[((size_t)y * w + x) * 4];
                p[0] = (unsigned char)ImClamp(r * vig, 0.0f, 255.0f);
                p[1] = (unsigned char)ImClamp(g * vig, 0.0f, 255.0f);
                p[2] = (unsigned char)ImClamp(b * vig, 0.0f, 255.0f);
                p[3] = 255;
            }
        }
    }

    inline unsigned char* At(int x, int y) { return &px[((size_t)y * w + x) * 4]; }
};

// ---------------------------------------------------------------------------
// Textures
// ---------------------------------------------------------------------------
struct Tex {
    const unsigned char* px = nullptr;
    int w = 0, h = 0;
    bool owned = false;
};

static std::vector<Tex> g_tex;   // index == ImTextureID

static ImTextureID AddTexture(const unsigned char* px, int w, int h, bool owned) {
    Tex t; t.px = px; t.w = w; t.h = h; t.owned = owned;
    g_tex.push_back(t);
    return (ImTextureID)g_tex.size();   // IDs start at 1
}

// ---------------------------------------------------------------------------
// Rasteriser
// ---------------------------------------------------------------------------
static inline float EdgeFn(const ImVec2& a, const ImVec2& b, const ImVec2& p) {
    return (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);
}

static void BlendPixel(Canvas& cv, int x, int y, float sr, float sg, float sb, float sa) {
    if (sa <= 0.001f) return;
    unsigned char* d = cv.At(x, y);
    const float ia = 1.0f - sa;
    d[0] = (unsigned char)ImClamp(sr * sa * 255.0f + d[0] * ia, 0.0f, 255.0f);
    d[1] = (unsigned char)ImClamp(sg * sa * 255.0f + d[1] * ia, 0.0f, 255.0f);
    d[2] = (unsigned char)ImClamp(sb * sa * 255.0f + d[2] * ia, 0.0f, 255.0f);
    d[3] = 255;
}

static void Rasterize(Canvas& cv, ImDrawData* dd, float S) {
    for (int li = 0; li < dd->CmdListsCount; ++li) {
        const ImDrawList* cl = dd->CmdLists[li];
        for (int ci = 0; ci < cl->CmdBuffer.Size; ++ci) {
            const ImDrawCmd& cmd = cl->CmdBuffer[ci];
            if (cmd.UserCallback) continue;
            if (cmd.ElemCount == 0) continue;

            int cx0 = (int)floorf(cmd.ClipRect.x * S), cy0 = (int)floorf(cmd.ClipRect.y * S);
            int cx1 = (int)ceilf(cmd.ClipRect.z * S), cy1 = (int)ceilf(cmd.ClipRect.w * S);
            cx0 = ImClamp(cx0, 0, cv.w); cx1 = ImClamp(cx1, 0, cv.w);
            cy0 = ImClamp(cy0, 0, cv.h); cy1 = ImClamp(cy1, 0, cv.h);
            if (cx1 <= cx0 || cy1 <= cy0) continue;

            Tex tex;
            {
                size_t id = (size_t)cmd.GetTexID();
                if (id > 0 && id <= g_tex.size()) tex = g_tex[id - 1];
            }

            const ImDrawIdx* idx = cl->IdxBuffer.Data + cmd.IdxOffset;
            const ImDrawVert* vtx = cl->VtxBuffer.Data + cmd.VtxOffset;

            for (unsigned int i = 0; i + 2 < cmd.ElemCount; i += 3) {
                ImDrawVert a = vtx[idx[i]];
                ImDrawVert b = vtx[idx[i + 1]];
                ImDrawVert c = vtx[idx[i + 2]];

                ImVec2 pa(a.pos.x * S, a.pos.y * S), pb(b.pos.x * S, b.pos.y * S), pc(c.pos.x * S, c.pos.y * S);
                float area = EdgeFn(pa, pb, pc);
                if (fabsf(area) < 1e-6f) continue;
                if (area < 0) { std::swap(pb, pc); std::swap(b, c); area = -area; }

                int minx = (int)floorf(ImMin(pa.x, ImMin(pb.x, pc.x)));
                int maxx = (int)ceilf(ImMax(pa.x, ImMax(pb.x, pc.x)));
                int miny = (int)floorf(ImMin(pa.y, ImMin(pb.y, pc.y)));
                int maxy = (int)ceilf(ImMax(pa.y, ImMax(pb.y, pc.y)));
                minx = ImClamp(minx, cx0, cx1 - 1); maxx = ImClamp(maxx, cx0, cx1 - 1);
                miny = ImClamp(miny, cy0, cy1 - 1); maxy = ImClamp(maxy, cy0, cy1 - 1);

                const float inv = 1.0f / area;
                for (int y = miny; y <= maxy; ++y) {
                    for (int x = minx; x <= maxx; ++x) {
                        ImVec2 p(x + 0.5f, y + 0.5f);
                        float w0 = EdgeFn(pb, pc, p) * inv;
                        float w1 = EdgeFn(pc, pa, p) * inv;
                        float w2 = EdgeFn(pa, pb, p) * inv;
                        if (w0 < -0.0001f || w1 < -0.0001f || w2 < -0.0001f) continue;

                        float r = (a.col & 0xFF) * w0 + (b.col & 0xFF) * w1 + (c.col & 0xFF) * w2;
                        float g = ((a.col >> 8) & 0xFF) * w0 + ((b.col >> 8) & 0xFF) * w1 + ((c.col >> 8) & 0xFF) * w2;
                        float bl = ((a.col >> 16) & 0xFF) * w0 + ((b.col >> 16) & 0xFF) * w1 + ((c.col >> 16) & 0xFF) * w2;
                        float al = ((a.col >> 24) & 0xFF) * w0 + ((b.col >> 24) & 0xFF) * w1 + ((c.col >> 24) & 0xFF) * w2;

                        float tr = 255, tg = 255, tb = 255, ta = 255;
                        if (tex.px) {
                            float u = a.uv.x * w0 + b.uv.x * w1 + c.uv.x * w2;
                            float v = a.uv.y * w0 + b.uv.y * w1 + c.uv.y * w2;
                            float fx = u * tex.w - 0.5f, fy = v * tex.h - 0.5f;
                            int x0 = (int)floorf(fx), y0 = (int)floorf(fy);
                            float ax = fx - x0, ay = fy - y0;
                            int x1 = ImClamp(x0 + 1, 0, tex.w - 1), y1 = ImClamp(y0 + 1, 0, tex.h - 1);
                            x0 = ImClamp(x0, 0, tex.w - 1); y0 = ImClamp(y0, 0, tex.h - 1);
                            const unsigned char* p00 = tex.px + ((size_t)y0 * tex.w + x0) * 4;
                            const unsigned char* p10 = tex.px + ((size_t)y0 * tex.w + x1) * 4;
                            const unsigned char* p01 = tex.px + ((size_t)y1 * tex.w + x0) * 4;
                            const unsigned char* p11 = tex.px + ((size_t)y1 * tex.w + x1) * 4;
                            auto mix4 = [&](int c) {
                                return (p00[c] * (1 - ax) + p10[c] * ax) * (1 - ay) +
                                       (p01[c] * (1 - ax) + p11[c] * ax) * ay;
                            };
                            tr = mix4(0); tg = mix4(1); tb = mix4(2); ta = mix4(3);
                        }
                        float sr = (r * tr / 255.0f) / 255.0f;
                        float sg = (g * tg / 255.0f) / 255.0f;
                        float sb = (bl * tb / 255.0f) / 255.0f;
                        float sa = (al * ta / 255.0f) / 255.0f;
                        BlendPixel(cv, x, y, sr, sg, sb, sa);
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// PNG out (PPM hand-off keeps the harness dependency free)
// ---------------------------------------------------------------------------
static void SavePPM(const Canvas& cv, const char* path) {
    FILE* f = fopen(path, "wb");
    if (!f) { printf("!! cannot write %s\n", path); return; }
    fprintf(f, "P6\n%d %d\n255\n", cv.w, cv.h);
    for (size_t i = 0; i < cv.px.size(); i += 4)
        fwrite(&cv.px[i], 1, 3, f);
    fclose(f);
}

// ---------------------------------------------------------------------------
// Scene driver
// ---------------------------------------------------------------------------
static ax::Model         g_model;
static ax::ShellState    g_shell;
static ax::OrbState      g_orb;
static bool              g_dummy[8] = {true, true, false, false, true, false, false, false};
static float             g_lineW = 1.4f, g_ox = 2.5f, g_oy = -1.5f, g_sc = 1.002f;
static int               g_tab = 0;
static bool              g_menuOpen = true;

static void FillModel() {
    g_model.esp         = &g_dummy[0];
    g_model.predict     = &g_dummy[1];
    g_model.pockets     = &g_dummy[2];
    g_model.pocketState = &g_dummy[3];
    g_model.autoAim     = &g_dummy[4];
    g_model.autoPlay    = &g_dummy[5];
    g_model.autoQueue   = &g_dummy[6];
    g_model.ghost       = &g_dummy[7];
    g_model.lineWidth   = &g_lineW;
    g_model.offsetX     = &g_ox;
    g_model.offsetY     = &g_oy;
    g_model.geomScale   = &g_sc;
    g_model.tab         = &g_tab;
    g_model.telemetry.booted     = true;
    g_model.telemetry.inGame     = true;
    g_model.telemetry.playerTurn = true;
    g_model.telemetry.nineBall   = false;
    g_model.telemetry.callPocket = false;
    g_model.telemetry.gmState    = 4;
    g_model.telemetry.mmState    = 36;
    g_model.telemetry.balls      = 11;
    g_model.telemetry.mode       = 2;
    g_model.telemetry.fps        = 60;
    g_model.telemetry.targetBall = 7;
    g_model.telemetry.targetPocket = 3;
    g_model.telemetry.modeName   = "M9 / 500K";
    g_model.telemetry.autoState  = "Idle";
    g_model.telemetry.ruleName   = "8-BALL";
    snprintf(g_model.telemetry.tablePtr, sizeof(g_model.telemetry.tablePtr), "0x%llX", 0x7B3F21A0ull);
}

int main(int argc, char** argv) {
    const int    kFrames = 90;
    const float  kS      = 2.0f;         // supersample for crisp screenshots
    const ImVec2 disp(390.0f, 844.0f);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.DisplaySize = disp;
    io.DeltaTime = 1.0f / 60.0f;

    // same compressed Vietnamese face the tweak ships with
    io.Fonts->AddFontFromMemoryCompressedTTF((void*)zzz_compressed_data, zzz_compressed_size,
                                             40.0f, nullptr, io.Fonts->GetGlyphRangesVietnamese());
    unsigned char* fpx = nullptr; int fw = 0, fh = 0;
    io.Fonts->GetTexDataAsRGBA32(&fpx, &fw, &fh);
    ImTextureID fontId = AddTexture(fpx, fw, fh, false);
    io.Fonts->SetTexID(fontId);

    // logo
    std::vector<unsigned char> logo;
    {
        FILE* f = fopen("logo.bin", "rb");
        if (f) { logo.resize(256 * 256 * 4); fread(logo.data(), 1, logo.size(), f); fclose(f); }
    }
    if (!logo.empty()) g_model.logoTexture = AddTexture(logo.data(), 256, 256, false);
    g_model.logoAspect = 1.0f;

    FillModel();
    g_shell.visible = true;
    g_shell.tab = 0;
    g_shell.pageT = 0.0f;

    struct Shot {
        const char* file; int tab; bool menu; bool gameBg; ImVec2 mouse;
        float open; float pageT; int frames; bool dirty[5];
    };
    Shot shots[] = {
        {"shot_dash.ppm", 0, true,  false, ImVec2(120, 300), 1.0f, 9.0f,  90, {false,false,false,false,false}},
        {"shot_aim.ppm",  1, true,  false, ImVec2(300, 420), 1.0f, 9.0f,  90, {false,false,false,false,false}},
        {"shot_auto.ppm", 2, true,  false, ImVec2(150, 620), 1.0f, 9.0f,  90, {false,false,false,false,false}},
        {"shot_sys.ppm",  3, true,  false, ImVec2(60, 700),  1.0f, 9.0f,  90, {false,false,false,false,false}},
        {"shot_orb.ppm",  0, false, true,  ImVec2(10, 10),   1.0f, 9.0f,  90, {false,false,false,false,false}},
        {"shot_off.ppm",  0, true,  true,  ImVec2(10, 10),   1.0f, 9.0f,  90, {true,false,false,false,false}},
        {"seq1.ppm",      0, true,  true,  ImVec2(10, 10),   0.26f, 0.06f, 2, {false,false,false,false,false}},
        {"seq2.ppm",      0, true,  true,  ImVec2(10, 10),   0.52f, 0.16f, 1, {false,false,false,false,false}},
        {"seq3.ppm",      0, true,  true,  ImVec2(10, 10),   0.80f, 0.26f, 1, {false,false,false,false,false}},
    };

    for (int s = 0; s < (int)(sizeof(shots) / sizeof(shots[0])); ++s) {
        g_tab = shots[s].tab;
        g_shell.tab = shots[s].tab;
        g_shell.pageT = shots[s].pageT;
        g_menuOpen = shots[s].menu;
        g_shell.open = shots[s].open;
        g_shell.offset = ImVec2(0, 0);
        g_shell.sheen = 0.0f;

        bool holdEsp = g_dummy[0];
        if (shots[s].dirty[0]) g_dummy[0] = false;

        Canvas cv;
        cv.Init((int)(disp.x * kS), (int)(disp.y * kS), shots[s].gameBg);

        float t = 3.0f;
        const int frames = shots[s].frames;
        for (int f = 0; f < frames; ++f) {
            io.DisplaySize = disp;
            io.DeltaTime = 1.0f / 60.0f;
            io.MousePos = shots[s].mouse;
            io.MouseDown[0] = false;

            if (shots[s].dirty[0] == false && shots[s].open < 0.999f && f == 0) {
                // hold the requested point of the bloom curve
                g_shell.open = shots[s].open;
            } else if (shots[s].menu && shots[s].open >= 0.999f) {
                g_shell.open = 1.0f;
            }
            g_shell.pageT += (f == 0 ? 0.0f : 1.0f / 60.0f);

            ImGui::NewFrame();
            ax::Rect panelBlocked = g_menuOpen
                ? ax::MkRect(disp.x * 0.5f - 192, disp.y * 0.5f - 306, 384, 612)
                : ax::MkRect(0, 0, 0, 0);
            if (ax::OrbFrame(g_model, disp, io.DeltaTime, t, g_orb, g_menuOpen, panelBlocked))
                g_menuOpen = !g_menuOpen;
            if (g_menuOpen) ax::ShellFrame(g_model, disp, io.DeltaTime, t, g_orb.pixel, g_shell);
            ImGui::Render();

            t += 1.0f / 60.0f;
            if (f == frames - 1) Rasterize(cv, ImGui::GetDrawData(), kS);
        }
        g_dummy[0] = holdEsp;
        SavePPM(cv, shots[s].file);
        printf("[shot] %s\n", shots[s].file);
    }
    return 0;
}
