#!/usr/bin/env bash
# Rasterise the Apex interface on a desktop CPU (no GPU, no device, no drivers).
set -euo pipefail
cd "$(dirname "$0")"
g++ -std=c++17 -O2 -I ../.. -o render main.cpp \
    ../../ImGui/imgui.cpp ../../ImGui/imgui_draw.cpp \
    ../../ImGui/imgui_tables.cpp ../../ImGui/imgui_widgets.cpp
./render
for f in shot_*.ppm; do convert "$f" "${f%.ppm}.png" && rm "$f"; done
echo "wrote: $(ls shot_*.png | tr '\n' ' ')"
