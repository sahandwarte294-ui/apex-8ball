# APEX ENGINE 2.1.0

A full rebuild of the 8 Ball Pool overlay: the old ImGui tab panel is gone, replaced by a
floating orb and a four-page glass board. Every pixel of the interface is now custom drawn —
no `ImGui::Checkbox`, no `BeginTabBar`, no default style colours anywhere in the tree.

---

## 1. What changed

### Interface

| Before | Now |
|---|---|
| 510 × 380 dark window, fixed centre | 384 × 612 board, drag by the header, remembers where you left it |
| `StyleColorsDark()` + a blue accent | obsidian glass + champagne gold, layered gradients and coloured vertex fills |
| Three tabs (ESP / Auto / Misc) with 20+ debug lines dumped on screen | Four pages — **DASH / AIM / AUTO / SYS** — with cards, and diagnostics collapsed into one telemetry card |
| Stock ImGui checkboxes and sliders | Custom capsule switches with travelling knobs and gold halo, precision sliders with live value chips |
| Flat everything | Every surface has elevation: stacked soft shadow, vertical gradient, 1 px top highlight, bevel |
| Instant show/hide | Bloom-open from the orb: scale + alpha + positional interpolation, staggered card reveals, one-off sheen sweep |
| Debug dump inside the menu | Saved to `Documents/apex_session.log` from the SYS page |

### Entry points

* **Floating orb** (30 pt radius, right edge by default) — the Apex mark inside a glass disc
  with a rotating arc set, breathing halo and pulse rings.
  * tap → open / close the board
  * drag → follows the finger, docks to the nearest edge, remembers the anchor
  * hold 0.6 s → **ghost mode**: the orb fades to ~18 % and stays tappable
* **Close** — the X in the header, a downward swipe on the header, or tapping the orb again.
* **Fallback** — 3 fingers, 3 taps. Works even if the orb is ghosted off the screen.
* Touch routing is orb-aware: while the board is closed only the orb's circle receives
  touches, everything else falls through to the game.
* The old grey corner button (`AutoPlay::DrawToggleButton`) is gone — the orb is the only
  on-screen control outside the board.

### Architecture

```
Core/Engine.h          game side only — memory reads, solver, automation, prefs
Bridge/EngineBridge.h  the single seam: fills an ApexModel, exposes 4 actions
Apex/                  interface only — knows nothing about GameManager
ImGuiDrawView.mm       Metal host: engine tick → orb → board → present
```

The interface never includes `Engine.h`; the engine never includes a widget. That seam is
what makes the redesign possible without touching a single offset or solver routine.

---

## 2. Controls

| Surface | Action | Result |
|---|---|---|
| Orb | tap | open / close board |
| Orb | drag | move + dock to edge |
| Orb | hold | ghost / un-ghost |
| Header | drag | move board |
| Header | swipe down | close |
| Header X | tap | close |
| Anywhere | 3 fingers × 3 taps | toggle board |

**DASH** master switch, four quick tiles (prediction, pockets, auto aim, auto queue),
live FPS / ball count / turn chips, session summary.
**AIM** vision toggles, line width, X/Y offset, scale, reset geometry.
**AUTO** auto aim, autoplay, start/stop session, solver readout, rematch queue.
**SYS** capture guard (hide from recordings), telemetry, export log, hide panel.

---

## 3. Build

Requirements: Theos, an iOS 14+ SDK in `$THEOS/sdks`, and a jailbroken 64-bit device.

```bash
export THEOS=~/theos
cd ApexBoard
./build.sh                # release
./build.sh debug          # debug
```

`build.sh` produces:

```
packages/com.apex.board_2.1.0_iphoneos-arm64.deb
.theos/obj/arm64/ApexBoard.dylib
.theos/obj/arm64e/ApexBoard.dylib
```

Manual equivalent:

```bash
make clean && make package
```

### Install

```bash
# package (recommended, registers the filter automatically)
dpkg -i packages/com.apex.board_2.1.0_iphoneos-arm64.deb
# or copy the dylib and let the injection layer pick it up
cp .theos/obj/arm64/ApexBoard.dylib /var/jb/usr/lib/TweakInject/
respring
```

The filter targets `com.miniclip.8ballpool` only (`ApexBoard.plist`).

---

## 4. Assets

The Apex mark ships **inside the binary as Base64 PNG** (`Apex/ApexLogo.h`) and is decoded to
a Metal texture at boot:

```objc
g_apexMarkTexture = ApexTextureFromBase64(kApexMarkBase64, _device);
g_model.logoTexture = (ImTextureID)(intptr_t)(__bridge void *)g_apexMarkTexture;
```

| Constant | Size | Use |
|---|---|---|
| `kApexMarkBase64` | 224 × 224 | orb, header tile, hero watermark |
| `kApexLockupBase64` | 176 × 311 | full lockup with the APEX wordmark |

Both are luminance + alpha PNGs, so the renderer can tint them gold without a second sprite.
Source PNGs are in `Assets/`.

---

## 5. Tuning

Everything visual is in two files:

* `Apex/ApexStyle.h` — palette (`ink`, `gold`, `txt`), easing curves, the animation slot table.
* `Apex/ApexShell.h` — panel size, header, rail, page composition, open/close timing.
* `Apex/ApexOrb.h` — orb radius, pulse rates, dock behaviour, ghost threshold.

Example: warmer accent →

```cpp
namespace gold {
    constexpr ImU32 Hi   = C(255, 231, 178);
    constexpr ImU32 Base = C(233, 187, 112);
    constexpr ImU32 Deep = C(191, 132, 48);
}
```

Example: faster bloom → in `imGuiDrawView.mm` raise the open speed (`3.6f`).

---

## 6. Offline preview

`Tools/preview/` rasterises real ImGui frames on a desktop CPU — no GPU, no device — so the
interface can be reviewed and diffed while iterating:

```bash
cd Tools/preview
g++ -std=c++17 -O2 -I ../.. -o render main.cpp \
    ../../ImGui/imgui.cpp ../../ImGui/imgui_draw.cpp \
    ../../ImGui/imgui_tables.cpp ../../ImGui/imgui_widgets.cpp
./render        # writes shot_*.ppm
```

It loads the same compressed face, the same Base64 mark and the same Apex headers the tweak
uses, so the output matches the device layout 1:1 (screenshots in `Screenshots/`).

---

## 7. Notes

* Tested layout at 390 × 844 pt; the board shrinks to fit anything narrower and keeps its
  proportions on iPads.
* Settings persist through `NSUserDefaults`: toggles, geometry, active tab, orb anchor and
  board offset.
* The capture guard is unchanged in behaviour — it is now driven by the SYS page switch and
  stays in sync with the secure-text layer each frame.
